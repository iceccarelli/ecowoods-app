# 01_Maple_Giorgia_Ch1_Before_Light_Natural

Maple house, chapter 1. Light / natural oak before the dark stain. Same curved stair as chapter 2.

## Placement

| Surface | Folder | Size |
|---|---|---|
| ecowoods.ca case study / proof / carousel | `web_1920x1080/` | 1920×1080, 16:9 |
| Instagram feed / Pinterest | `social_1080x1350/` | 1080×1350, 4:5 |
| Reels / Stories / TikTok / YouTube | `01_Maple_Giorgia_Ch1_Before_Light_Natural.mp4` | 1920×1080 H.264 |

Suggested site drop: `apps/web/public/proof/01_Maple_Giorgia_Ch1_Before_Light_Natural/`

Filenames are story order. `00_` is the opening card. `99_` is the close.

Do not invent extra job photos. Every interior frame is from the site.
