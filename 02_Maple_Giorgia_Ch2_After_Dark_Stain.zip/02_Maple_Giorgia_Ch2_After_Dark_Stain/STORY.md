# 02_Maple_Giorgia_Ch2_After_Dark_Stain

Maple house, chapter 2. Dark stain aftermath of chapter 1. Same chandelier, well, and marble foyer.

## Placement

| Surface | Folder | Size |
|---|---|---|
| ecowoods.ca case study / proof / carousel | `web_1920x1080/` | 1920×1080, 16:9 |
| Instagram feed / Pinterest | `social_1080x1350/` | 1080×1350, 4:5 |
| Reels / Stories / TikTok / YouTube | `02_Maple_Giorgia_Ch2_After_Dark_Stain.mp4` | 1920×1080 H.264 |

Suggested site drop: `apps/web/public/proof/02_Maple_Giorgia_Ch2_After_Dark_Stain/`

Filenames are story order. `00_` is the opening card. `99_` is the close.

Do not invent extra job photos. Every interior frame is from the site.
