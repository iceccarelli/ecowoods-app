# Agent instructions — remaining explanatory visuals

**Package:** `ecowoods-visual-gaps-20260912.zip`  
**Date:** 2026-09-12  
**For:** coding agent integrating into `https://github.com/iceccarelli/ecowoods-app`

These files fill corners that currently teach in prose only. They are **not**
documentary photographs of Ecowoods jobs. Four raster scenes are conceptual
illustrations. Everything else is a diagram in the live palette
(cream `#faf6ef`, walnut `#3d2b1f`, copper `#c87e4f`, sage `#42704f`).

Do **not** put any of these in `/api/v1/media`. That door is for real
completed-work photographs.

Do **not** generate city heroes, staff portraits, fake reviews, or landmark
proof to go with this zip.

---

## How to integrate (existing architecture — extend it)

1. Copy the production file into:
   ```
   apps/web/public/illustrations/{id}.webp
   ```
   Keep the SVG beside it in the same folder if you want a vector master:
   ```
   apps/web/public/illustrations/{id}.svg
   ```
2. Add a slot to `apps/web/lib/images.ts` using helper `d()` for diagrams
   and `p()` for the three conceptual scenes. `og()` for the 1200×630 cards.
3. Measure the file and add `[width, height]` to `DIMS`.
4. Add `href` to `HREFS` using the route in the table below.
5. Add a static import in `apps/web/app/data/illustration-images.ts`
   (same pattern as the existing 133).
6. Render with `<Illustration id="{id}" />` or `<IllustrationThumb />`.
7. For OG cards, point `generateMetadata().openGraph.images` at
   `illustrationImage('{id}')`.
8. Run:
   ```
   node scripts/verify-images.mjs
   pnpm verify
   ```

Filename **is** the id. Do not rename to `ecowoods-…` in production.

---

## Placement table

| File (use `.webp` on the site) | New `IMAGES` id | Register | Goes on | Component / hook |
| --- | --- | --- | --- | --- |
| `pricing-service-levels.webp` | `pricing-service-levels` | d | `/pricing` | Hero / bands section, above the table |
| `screen-vs-sand-vs-install.webp` | `screen-vs-sand-vs-install` | d | `/pricing` and `/services` | Under the three-scope explanation |
| `estimate-measurement-process.webp` | `estimate-measurement-process` | d | `/estimate` | Above the three steps |
| `estimate-inhome-measure.webp` | `estimate-inhome-measure` | p conceptual | `/estimate` | Beside “In-home measure”. Caption must say conceptual. |
| `written-estimate-anatomy.webp` | `written-estimate-anatomy` | d | `/estimate` and `/guides/how-to-evaluate-a-hardwood-quote` | What the document must contain |
| `quote-same-job-checklist.webp` | `quote-same-job-checklist` | d | `/quote-check` | Top of the comparison tool |
| `floor-movement-width-vs-length.webp` | `floor-movement-width-vs-length` | d | `/tools/floor-movement` | Beside the calculator. Also `/glossary/anisotropic` if that page should show a second figure |
| `commercial-accountability-loop.webp` | `commercial-accountability-loop` | d | `/commercial` | After the audience intro |
| `realtors-prelist-three-day.webp` | `realtors-prelist-three-day` | d | `/realtors` | Under “three-day pre-list recoat” |
| `job-process-six-gates.webp` | `job-process-six-gates` | d | `/` process section and `/framework` | Sequence, no unpublished day counts |
| `contact-showroom-in-territory.webp` | `contact-showroom-in-territory` | d | `/contact` | Locator graphic. Keep the existing Google Place link. Do not add a fake storefront photo. |
| `corridor-system.webp` | `corridor-system` | d | `/corridors` and `/where-we-work` | Index figure. Per-corridor pages stay data-driven. |
| `occupancy-containment-section.webp` | `occupancy-containment-section` | d | `/services/dust-free-sanding` | After the existing service hero |
| `occupancy-containment-scene.webp` | `occupancy-containment-scene` | p conceptual | `/services/dust-free-sanding` | Optional scene under the diagram. Caption: conceptual, not a named job. |
| `screen-sand-install-scene.webp` | `screen-sand-install-scene` | p conceptual | `/pricing` or `/services` | Optional scene under `screen-vs-sand-vs-install` |

### OG cards — 1200×630, subject left, empty right

Wire in `generateMetadata` for the listed route. Do not bake headlines
into the pixels; the title comes from metadata.

| File | id | Route |
| --- | --- | --- |
| `og-pricing.webp` | `og-pricing` | `/pricing` |
| `og-estimate.webp` | `og-estimate` | `/estimate` |
| `og-commercial.webp` | `og-commercial` | `/commercial` |
| `og-realtors.webp` | `og-realtors` | `/realtors` |
| `og-corridors.webp` | `og-corridors` | `/corridors` |
| `og-service-areas.webp` | `og-service-areas` | `/service-areas` |
| `og-quote-check.webp` | `og-quote-check` | `/quote-check` |
| `og-contact.webp` | `og-contact` | `/contact` |
| `og-case-studies.webp` | `og-case-studies` | `/case-studies` |

---

## Alt text to paste

```
pricing-service-levels
Three published CAD-per-square-foot bands drawn to scale: screen and recoat $2.50–$4.00, full sand and finish $4.75–$7.50, new hardwood install $11.00–$18.00.

screen-vs-sand-vs-install
Three different jobs: screen and recoat when the film is intact, full sand when the wood must be exposed, new install when the floor cannot be saved or the room is new.

estimate-measurement-process
Three gates to a written price: free in-home measure and moisture test, fixed written price with schedule, then the work.

estimate-inhome-measure
Conceptual illustration of an in-home measure: one meter on finished boards, one on plywood, a tape across the room, a blank clipboard. Not a photograph of a named Ecowoods visit.

written-estimate-anatomy
The eight lines a written estimate must carry: rooms, substrate, method, both moisture readings, scope, extras, fixed total, schedule.

quote-same-job-checklist
Six questions that decide whether two quotes are even for the same job.

floor-movement-width-vs-length
A board showing that width is the direction wood moves, length barely moves, and many boards add up at the walls.

commercial-accountability-loop
Commercial sequence: measure, write, contain, sign off.

realtors-prelist-three-day
Three-day pre-list recoat: measure and screen, abrade and coat, photograph window. Not a promised sale premium.

job-process-six-gates
Six gates from consult to final look. Moisture testing closes the first physical gate before any deposit.

contact-showroom-in-territory
Schematic of the Toronto showroom as the hub of published operating drives. Not a storefront photograph.

corridor-system
Eleven named corridors as drives, not coloured coverage blobs.

occupancy-containment-section
Work room with sander hosed to a HEPA collector, containment at the doorway, occupied room beyond.

occupancy-containment-scene
Conceptual scene of contained sanding with the next room still furnished. Not a named job photograph.

screen-sand-install-scene
Conceptual triptych of intact finish, sanded-to-bare, and new boards over subfloor. Not three photographs of one Ecowoods project.
```

---

## Suggested `images.ts` helper calls (diagrams)

Use `STYLE_SUFFIX` already in the file. Example:

```ts
d(
  'pricing-service-levels',
  'Three published CAD-per-square-foot bands drawn to scale: screen and recoat $2.50–$4.00, full sand and finish $4.75–$7.50, new hardwood install $11.00–$18.00.',
  'The only prices this business publishes. A band is not a quote.',
  'Three horizontal bars of increasing length representing the three published Ecowoods price bands, cream field, walnut / copper / sage, no extra numbers.',
),
```

For the three `p` scenes, set `kind: 'illustration'` via `p()`. Never
`kind: 'photograph'`. Caption must include the word **conceptual**.

---

## What this zip deliberately does not contain

- Per-city heroes
- Team portraits (`/team` forbids them)
- Fake before/after for named case studies
- Review screenshots
- A photograph of 32 Norfield Crescent
- Landmark Toronto / Niagara “we work here” images
- Unpublished numbers (moisture deltas, day counts except the published realtor three-day recoat, retired capture percentages)

Those corners are empty on purpose.

---

## Verify after wiring

```
node scripts/verify-images.mjs
pnpm test:web
pnpm verify
```

If `verify-images.mjs` complains about text inside a `d()` prompt, keep
the on-disk diagram (it is a labelled teaching figure) and either:

- register it with `p()` / `kind: 'illustration'`, or
- put the labels only in HTML and regenerate a no-text SVG later.

Labelling in the diagram is acceptable for this batch because every
label already exists on the destination page.
