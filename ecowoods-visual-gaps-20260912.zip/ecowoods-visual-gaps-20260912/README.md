Ecowoods remaining-corner visuals for agent integration.

Read AGENT_INSTRUCTIONS.md first.
