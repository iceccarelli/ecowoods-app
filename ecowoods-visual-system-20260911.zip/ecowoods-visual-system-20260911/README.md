# Ecowoods visual integration pack — 2026-09-11

Batch 001. Generated editorial + diagram masters for Ecowoods Hardwood Flooring Inc.

## Read this before you drop files into the repo

These are **generated conceptual images**. They are not photographs of Ecowoods jobs, staff, or premises.

The live repo already has 133 registered illustrations in `apps/web/public/illustrations/` and a hard rule in `apps/web/lib/images.ts`:

- `kind: 'photograph'` requires real provenance
- generated work is `diagram` or `illustration` only
- `scripts/verify-images.mjs` fails the build if you lie about that

## Layout

```
images/generated/   protocol filenames (ecowoods-…webp / og jpg)
images/drop-in/     optional copies named as repo ids (service-installation.webp, …)
images/og/          1200×630 social crops
previews/           small jpgs
manifests/          MANIFEST.json
```

## Safe integration

1. Do **not** blindly overwrite `service-installation.webp` and friends if those pages already ship art you like.
2. Add **new** ids to `apps/web/lib/images.ts` (`home-hero`, `about-materials`, `og-home`, …) with `kind: 'illustration'` or `'diagram'`, alt + caption + prompt from MANIFEST.json.
3. Copy the matching webp into `apps/web/public/illustrations/<id>.webp`.
4. `node scripts/gen-illustration-imports.mjs`
5. Mount `<Illustration id="home-hero" />` on the real route.
6. `pnpm verify:images && pnpm verify`

## Not in this zip (on purpose)

- Fake employee portraits
- Fake review screenshots
- Fake certificates / licences
- 45 near-identical city heroes
- Hand-labelled corridor maps (the app draws those from `CORRIDORS` / `MARKETS`)
- The existing 400 production files already in the GitHub repo

## Quarantine

`images/generated/REJECT-contains-cn-tower.jpg` includes a recognizable Toronto landmark. Do not use it as local evidence.
