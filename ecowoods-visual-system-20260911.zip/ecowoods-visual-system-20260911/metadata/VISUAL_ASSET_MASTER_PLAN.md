# ECOWOODS VISUAL ASSET MASTER PLAN

**Depends on:** PHASE 0 audit
**Rule:** extend `apps/web/lib/images.ts`, `/api/v1/media`, and the existing guards. Do not fork the architecture.

---

## 1. Identity of an asset (overlay, not replacement)

Keep the live identity:

```
id            = service-installation
file          = service-installation.webp
path          = apps/web/public/illustrations/service-installation.webp
component     = <Illustration id="service-installation" />
href          = /services/hardwood-installation
```

Optional stable overlay for the protocol’s ID law:

```
VIS-SERVICE-001  →  service-installation
```

Filename law already in force: `[a-z0-9-]+.webp`, id == filename stem. That is the law the build will enforce. The longer `ecowoods-{surface}-{subject}-…` names are documentation aliases only.

---

## 2. Source classes (already in code)

| Protocol source | Repo `kind` | Allowed |
| --- | --- | --- |
| GENERATED_DIAGRAM | `diagram` | yes, prompt required, no text in `d` |
| GENERATED_ILLUSTRATION | `illustration` | yes, prompt required |
| OWNER_PHOTOGRAPH | `photograph` | yes, `provenance` required, no prompt |
| LICENSED_ASSET | not modelled | do not add without a new kind + guard |
| fake documentary | — | build-fail |

---

## 3. Generation batches (only measured holes)

### BATCH 0 — Documentation (no pixels)

- Rewrite `docs/visual/IMAGE_BRIEF.md` “what exists” table to match 133 live slots.
- Add `docs/visual/ECOWOODS_VISUAL_ARCHITECTURE.md`.
- Add `docs/visual/ECOWOODS_VISUAL_COVERAGE_MATRIX.md`.
- Add `docs/visual/ASSET_ID_MAP.json` if VIS-* IDs are wanted for planning.

### BATCH 001 — Quality corrections, not new concepts

- Inspect `framework-hero.webp` against the six canonical pillar names and the no-date rule. Regenerate **only if** the current file still contradicts `/framework`.
- Confirm each `service-*` slot is mounted on the service page. If a page still has an empty figure slot, that is integration work, not new art.

### BATCH 002 — OG cards that are actually missing

Add to `images.ts` as `og(...)` helpers, 1200×630, then generate:

- `og-home`
- `og-installation`
- `og-refinishing`
- `og-dust-free`
- `og-restoration`
- `og-inlays`
- `og-stairs`
- `og-service-areas`
- `og-authority` (or reuse `og-framework` if `/authority` is an alias — check routes first)
- `og-case-studies`

Wire via existing metadata patterns (`illustrationImage('og-about')`), not a new OG engine.

### BATCH 003 — Do not generate

- Per-city heroes
- Team portraits
- Fake case-study before/after
- Fake review UI
- Fake storefront
- Duplicate species interiors (gallery already has 36)
- Hand-labelled corridor SVGs (TerritoryMap already draws the truth)

### BATCH 004 — Real photography only (owner queue)

Execute `docs/PHOTO_QUEUE.md` when the owner supplies plates:

- Burlington, Hamilton, Grimsby, Barrie, Niagara Falls, Milton, St. Catharines
- Two frames minimum (room + ≤300mm detail)
- Register as `kind: 'photograph'` with shoot provenance
- Attach to `signatureProject` only after the page sentence matches the frame

### BATCH 005 — Process / estimate diagrams

Only after reading `ProcessDeck.tsx` and `/estimate`. If the UI already explains the sequence in HTML, do not bake the same sequence into six SVGs.

Candidates if a hole is real:

- estimate measurement flow (diagram)
- pricing inputs (may already be `price-bands-to-scale` + `change-order-drift`)

---

## 4. Integration checklist per new slot

1. Add the helper call in `apps/web/lib/images.ts` (`d` / `p` / `og`).
2. If file is not ready: full object literal with `status: 'pending'`.
3. Drop master → `scripts/prepare-illustrations.sh`.
4. `node scripts/gen-illustration-imports.mjs`
5. Mount `<Illustration id="…" />` on the real route.
6. `pnpm verify:images && pnpm verify:media && pnpm verify`
7. Production: `pnpm verify:live-images` so the URL is bytes, not a 404.

---

## 5. ZIP policy

Do not zip the whole repository. When a batch of *new* generated masters exists:

```
artifacts/visual/ecowoods-visual-batch-00N.zip
  images/
  prompts/
  manifests/
  metadata/
  previews/
  MANIFEST.json
  README.md
  CHECKSUMS.sha256
```

Masters that are already in `apps/web/public/illustrations/` do not need to be duplicated into a vanity zip unless the owner wants an offline handoff.

---

## 6. Definition of done (realistic)

Done is not “every protocol filename exists.”

Done is:

- Phase 0 audit accepted
- IMAGE_BRIEF reconciled to live manifest
- coverage matrix lists every major public route against *current* asset ids
- missing OG cards generated, registered, integrated, verified
- no new fake evidence
- `pnpm verify` green
- live image URLs 200 for the routes that claim them

Beautiful is not enough. The system already knows that.
