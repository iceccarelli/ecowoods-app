Flat vector technical illustration.
Palette: cream #faf6ef, walnut #3d2b1f, copper #c87e4f, sage #42704f.
2px linework, no photorealism, no text, no numbers, no logos.
Labels live in HTML.
