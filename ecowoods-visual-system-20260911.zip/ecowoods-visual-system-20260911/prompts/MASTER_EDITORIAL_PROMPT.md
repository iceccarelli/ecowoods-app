Premium editorial architectural photography for a Canadian hardwood-flooring company.
Quiet luxury, warm natural materials, physically plausible grain and light.
No text, logos, signage, certificates, review UI, addresses, or identifiable staff.
Not a documentary record of an Ecowoods job.
