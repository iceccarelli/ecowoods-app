# Ecowoods Visual Pack 15

## Purpose
Fifteen new production illustrations to explain housing construction differences, service-area geography, technical library structure, and key technical articles. All generated as diagrams/illustrations (never photographs), matching the existing visual language (cream #faf6ef, walnut #3d2b1f, copper #c87e4f, muted sage #42704f).

## Image IDs and Placements
1. area-housing-prewar-heritage — /service-areas/[city] (housing stock section)
2. area-housing-postwar-suburban — /service-areas/[city]
3. area-housing-condo-concrete-slab — /service-areas/[city]
4. area-housing-radiant-newbuild — /service-areas/[city]
5. service-areas-gta-corridors-map — /service-areas (after intro)
6. technical-library-corpus-map — /technical-library (intro)
7. technical-pillar-moisture-management — /technical-library (Moisture Management)
8. technical-pillar-wood-science — /technical-library (Wood Science)
9. technical-pillar-installation-finishing — /technical-library (Installation & Finishing)
10. article-subfloor-moisture-testing — /blog and article detail
11. article-hepa-dust-extraction — /blog and article detail
12. article-hardwood-species-comparison — /blog and article detail
13. article-water-vs-oil-finish — /blog and article detail
14. article-wood-acclimation-timeline — /blog and article detail
15. article-white-oak-vs-red-oak — /blog and article detail

All files: apps/web/public/illustrations/<id>.webp (1600x900)

## Integration
- Entries added to apps/web/lib/images.ts (kind illustration or diagram)
- Static imports regenerated via scripts/gen-illustration-imports.mjs
- Corridor map integrated on /service-areas
- Remaining images anchored for verification; final conditional placement by housingNote / pillar / article slug should be completed in page components using <Illustration id="..." />

## Verification
node scripts/verify-images.mjs
node scripts/gen-illustration-imports.mjs

Base SHA: eab7fd9dd512253f07ad71b9408017d6cd0b209f
