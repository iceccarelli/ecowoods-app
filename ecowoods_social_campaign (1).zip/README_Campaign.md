# Ecowoods Aggressive Paid Social Campaign Assets

**Campaign Name:** Ecowoods Hyper-Converting Paid Ads (Facebook / Instagram / TikTok)  
**Objective:** Drive immediate traffic to the floor designer + free in-home estimate booking pipeline at [ecowoods.ca](https://ecowoods.ca)  
**Tone:** Pattern-interrupting, aggressive, zero corporate fluff. Weaponize the four non-negotiables:

1. **99.7% dust-free HEPA sanding** (Festool + Bona Atomic)
2. **Fixed price in writing** — the number on paper is the number on the invoice
3. **Salaried master craftsmen only** — never subcontractors
4. **Toronto / GTA exclusive** operations with 25–50 year manufacturer warranties + zero-formaldehyde eco materials

---

## Asset Inventory

| File | Description | Primary Pain Point Attacked |
|------|-------------|-----------------------------|
| `01_before_after_oak.webp` | Split-screen 100-year-old Toronto red oak → flawless hardwax-oil | Worn floors + surprise fees |
| `02_festool_hepa_sanding.webp` | Master artisan + Festool HEPA sander in furnished room | Toxic dust / live-in impossibility |
| `03_white_oak_walnut_inlay.webp` | Wide-plank white oak + custom walnut fireplace inlay | Cookie-cutter floors / no design |
| `04_eco_finish_macro.webp` | Macro of water-based zero-formaldehyde finish on grain | Chemical off-gassing / cheap finishes |
| `05_homeowner_artisan_handshake.webp` | Handshake with official written quote on clipboard | Verbal estimates that balloon |

All images are photorealistic 8k-style DSLR captures optimized as high-quality WebP for fast social delivery.

---

## How to Use the Copy

Every asset has four ready-to-paste fields inside `campaign_assets.json`:

- **hook** (array of 3 lines) — first 3 lines of the ad. Pattern interrupt + pain.
- **body** — full weaponized copy that sells the guarantees.
- **caption** — Instagram/TikTok-optimized short version + Toronto SEO hashtags.
- **cta** — direct instruction to go to ecowoods.ca, use the designer, book the free estimate.

Load the JSON dynamically in your ad manager or creative pipeline. No fluff. Every sentence is designed to convert or disqualify.

---

## Deployment into Monorepo

Place these files into the existing Ecowoods monorepo at:

```
public/assets/marketing/
```

Exact Git commands (run from the root of `iceccarelli/ecowoods-app` after extracting the ZIP):

```bash
# 1. Extract the campaign package
unzip ecowoods_social_campaign.zip -d /tmp/ecowoods_campaign

# 2. Create the marketing assets directory if it doesn't exist
mkdir -p public/assets/marketing

# 3. Copy everything into the correct location
cp /tmp/ecowoods_campaign/*.webp public/assets/marketing/
cp /tmp/ecowoods_campaign/campaign_assets.json public/assets/marketing/
cp /tmp/ecowoods_campaign/README_Campaign.md public/assets/marketing/

# 4. Stage and commit
git add public/assets/marketing/
git commit -m "feat(marketing): add aggressive paid social campaign assets (5 images + JSON copy + README)

- 01_before_after_oak.webp
- 02_festool_hepa_sanding.webp
- 03_white_oak_walnut_inlay.webp
- 04_eco_finish_macro.webp
- 05_homeowner_artisan_handshake.webp
- campaign_assets.json (hooks, bodies, captions, CTAs)
- README_Campaign.md"

# 5. Push
git push origin main
```

---

## Quick Performance Notes

- **Primary conversion path:** Image click → ecowoods.ca floor designer → free estimate form
- **Secondary:** Direct “Book free estimate” button on site
- **Audience:** Toronto / GTA homeowners 35–65, household income $150k+, recently purchased or renovating older homes, Facebook/Instagram interest in home improvement + hardwood flooring
- **A/B suggestion:** Test Hook #1 vs Hook #2 on each creative. The “surprise fees” and “toxic dust” angles historically outperform pure beauty shots in this market.

---

**Built for conversion. Deploy and scale.**
