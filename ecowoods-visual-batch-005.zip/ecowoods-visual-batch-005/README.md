Ecowoods visual batch 005: 12 image files from production + maps.
