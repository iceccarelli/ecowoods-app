# AGENT INTEGRATION INSTRUCTIONS — Ecowoods Visual Batch 002

You are integrating generated explanatory images into https://github.com/iceccarelli/ecowoods-app.

Read this file before touching the repo.

## What this zip is

Batch 002. Explanatory diagrams (and two conceptual interiors) for pages that still need a picture of *the mechanism*, not another pretty room.

All files are GENERATED. In `apps/web/lib/images.ts` they MUST be:

- `kind: 'diagram'` for line drawings
- `kind: 'illustration'` for the two photoreal interiors
- NEVER `kind: 'photograph'`

`scripts/verify-images.mjs` will fail the build if you register any of these as photographs.

## What this zip is not

- Not fake Ecowoods jobs, staff, storefronts, reviews, certificates
- Not 45 city heroes
- Not a replacement for TerritoryMap / WorkMap (those are drawn from geo registries)
- Not a dump of the 133 illustrations already on `main`

If a live file already exists with the same *concept* (for example `term-acclimation.webp`, `fig-four-machines-roles.webp`, `guide-solid-vs-engineered.webp`), **do not overwrite it**. Add the new id from this pack (`term-acclimation-stacked`, `four-machines-roles`, `guide-solid-engineered-stacks`) and mount it only if the page still has an empty figure slot.

## Repo laws you must keep

1. Filename stem == `id`. Lowercase hyphenated ASCII. Example: `dustfree-airflow.webp` + `id: 'dustfree-airflow'`.
2. Files live in `apps/web/public/illustrations/`.
3. After copy: `node scripts/gen-illustration-imports.mjs`
4. Render with `<Illustration id="dustfree-airflow" />` (or IllustrationPair).
5. Alt describes the information. Do not start with "image of".
6. Caption is required for `p` / photoreal; use the caption from INTEGRATION_MAP.csv.
7. `href` on the manifest entry must be a real published route.
8. `pnpm verify:images && pnpm verify`

## Drop order

1. Copy `drop-in/<repo_id>.webp` → `apps/web/public/illustrations/<repo_id>.webp`
2. Add a `d(...)` or `p(...)` helper (or pending literal) in `apps/web/lib/images.ts`
3. Put the matching `href` in the HREFS map
4. Run `node scripts/gen-illustration-imports.mjs`
5. Mount the component on the route in INTEGRATION_MAP.csv
6. Do not lazy-load if it is the page LCP hero. These batch-002 files are mostly mid-page figures — lazy is correct.
7. Verify.

## Route → files (primary)

| Route | repo_id files to mount |
| --- | --- |
| `/services/dust-free-sanding` | dustfree-airflow |
| `/services/hardwood-installation` | install-sequence-icons, term-acclimation-stacked |
| `/services/floor-restoration` | restoration-damage-detail |
| `/services/custom-inlays` | inlays-design-process |
| `/pricing` | pricing-area-measurement, pricing-service-levels, guide-cost-inputs |
| `/estimate` | pricing-area-measurement |
| `/quote-check` | guide-quote-filter |
| `/framework` | protocol-gates |
| `/hardwood-floor-problems-toronto` | failure-cascade-tree, failure-cupping-crowning, failure-buckling-ridge |
| `/hardwood-floor-refinishing-toronto` | pricing-service-levels |
| `/papers/hardwood-refinishing-machines-and-sequence` | four-machines-roles, grit-progression, term-intercoat-screening-coats |
| `/papers/toronto-hardwood-climate-moisture-protocol` | protocol-gates, term-relative-humidity |
| `/guides/solid-vs-engineered-hardwood-toronto` | guide-solid-engineered-stacks, term-wear-layer-budget |
| `/guides/reference-condominium-concrete-slab` | assembly-condo-slab |
| `/guides/reference-radiant-heat-main-floor` | assembly-radiant-heat |
| `/guides/herringbone-chevron-parquet-toronto` | pattern-three-layouts, pattern-strip-vs-block |
| `/guides/how-to-evaluate-a-hardwood-quote` | guide-quote-filter |
| `/guides/hardwood-flooring-cost-toronto` | guide-cost-inputs, pricing-area-measurement |
| `/guides/white-oak-flooring-toronto` | guide-white-oak-interior |
| `/glossary/acclimation` | term-acclimation-stacked |
| `/glossary/expansion-gap` | term-expansion-gap-wall |
| `/glossary/cupping` and `/glossary/crowning` | failure-cupping-crowning |
| `/glossary/buckling` | failure-buckling-ridge |
| `/glossary/edge-peaking` | failure-edge-peaking-joint |
| `/glossary/wear-layer` | term-wear-layer-budget |
| `/glossary/anisotropic` | term-anisotropic-axes |
| `/glossary/relative-humidity` | term-relative-humidity |
| `/glossary/janka` | term-janka-dents |
| `/glossary/subfloor` | term-subfloor-three |
| `/tools/floor-movement` | term-anisotropic-axes |
| `/equipment` | four-machines-roles |
| `/corridors` `/where-we-work` | corridor-schematic-abstract as *optional companion only* — TerritoryMap remains source of truth |

## Helper shape to paste into images.ts

Use the existing `d()` / `p()` helpers. Example:

```
  d(
    'dustfree-airflow',
    'Sander hosed to a sealed collector with airflow chevrons and a doorway isolation sheet.',
    'Dust moves from the floor into a sealed collector. Isolation keeps the rest of the house outside the work zone.',
    'Flat vector technical illustration, cream #faf6ef, walnut #3d2b1f, copper #c87e4f, sage #42704f, 2px linework, no text. Floor sander hosed to sealed collector, isolation sheet across doorway, chevrons for airflow.',
  ),
```

Photoreal interiors (`restoration-damage-detail`, `guide-white-oak-interior`) use `p(...)` and `kind` illustration.

## Still not visualized on purpose

- `/team` — no portraits until real consented photos exist
- `/reviews` — no fake platform UI (batch 001 already has an atmosphere interior)
- `/contact` — no fake storefront; do not invent 32 Norfield Crescent
- Per-city heroes — wait for PHOTO_QUEUE owner plates
- Case-study “before/after” — only the real Vaughan stair project may be documentary

## Files

- `images/` protocol names
- `drop-in/` repo ids ready to copy
- `INTEGRATION_MAP.csv` machine-readable map
- `MANIFEST.json` full metadata
- `CHECKSUMS.sha256`
- `previews/` small jpgs for human review
