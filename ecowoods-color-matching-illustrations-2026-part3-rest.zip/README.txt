Ecowoods Hardwood Flooring Inc. — colour-matching illustration pack
====================================================================

Brand
-----
Ecowoods Hardwood Flooring Inc., Toronto. Est. 2000.
Phone (647) 244-5156.
Showroom 32 Norfield Crescent, Toronto ON M9W 1X6.
Canonical site: https://ecowoods.ca
Canonical repo: https://github.com/iceccarelli/ecowoods-app

These photographs support the site's honest claim:
colour matching is a process (identify → sample on the real board →
sign off in the room's light → say when it will not work).
Do not claim "exact match" in alt text, captions, or surrounding copy.
Alt text in MANIFEST.csv describes the process shown, not a guarantee.

How to install
--------------
Copy the five image folders into the Next.js public tree:

  images/color-matching/  →  apps/web/public/images/color-matching/
  images/guides/          →  apps/web/public/images/guides/
  images/species/         →  apps/web/public/images/species/
  images/services/        →  apps/web/public/images/services/
  images/case-studies/    →  apps/web/public/images/case-studies/

Each basename ships as both .jpg and .webp. Prefer .webp in <Image>.

Suggested Next.js usage
-----------------------
import Image from "next/image";

<Image
  src="/images/color-matching/cm-hub-hero-toronto-living-room.webp"
  alt="Toronto midtown living room with continuous satin white oak floor running onto a stair, late afternoon window light and warm LEDs"
  width={3840}
  height={2160}
  priority
/>

Full alt text, caption, page URL, repo page path and section for every
file is in MANIFEST.csv.

Sizes
-----
Heroes:            16:9   3840×2160
Process / details: 4:3    2400×1800
Species boards:    1:1    2000×2000
(species-same-stain-six-species is a lineup and ships at 2400×1800)

Reuse map
---------
species-* images may also be used on:
  /floor-studio
  /design
  /library
  /guides/white-oak-flooring-toronto
  /guides/red-oak-flooring-toronto
  /guides/hard-maple-flooring-toronto
  /guides/black-walnut-flooring-toronto
  /guides/hickory-flooring-toronto
  /guides/white-ash-flooring-toronto

service-stairs-matched-flight also serves /hardwood-stairs-toronto.

Reminder
--------
Do not invent company facts, prices, Janka numbers, or "exact match"
guarantees. The sample-board process is what Ecowoods commits to.
These frames were generated as photoreal editorial trade photographs
for page illustration. Review grain and lighting on a calibrated
display before publishing; reject any frame that reads as plastic,
illustrated, or that has baked-in text.

Pack date: 2026-09-19
File: ecowoods-color-matching-illustrations-2026.zip
47 basenames × 2 formats = 94 image files + MANIFEST.csv + README.txt
