Ecowoods visual batch 004: 36 image files from production + maps.
