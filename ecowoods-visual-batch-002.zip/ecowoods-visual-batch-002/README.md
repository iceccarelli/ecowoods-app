Ecowoods visual batch 002: 190 image files from production + maps.
