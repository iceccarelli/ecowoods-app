# Maple & Glass Residence
## Ecowoods field project — installation, stairs, transitions

**Working slug:** `maple-glass-residence`  
**Suggested URL:** `/projects/maple-glass-residence`  
**Case-study URL:** `/case-studies/maple-glass-residence`  
**Species:** Hard Maple (*Acer saccharum*), select grade  
**Pattern:** Straight plank, staggered end joints  
**Width (visual):** ~5″ plank  
**Finish:** Natural / satin, low-sheen — the floor returns light, it does not flash  
**Scope (approx.):** 1,800 sq ft of field + custom two-flight open-riser stair and landings  
**Duration:** One working week on site  
**Related trades in frame:** frameless glass guards, walnut millwork, large-format stone tile  

---

## What was done

This is a new-construction luxury residence. Ecowoods installed a continuous hard-maple floor through the upper suite, dressing rooms, stair void, halls and living room, then cut and set matching open-riser treads and landings so the stair is the same species, the same colour and the same sheen as the field.

The work, in order:

1. Moisture readings and a layout that keeps plank direction consistent from the primary window wall, through the dressing axis, across the void and down into the living room.
2. Installation of select hard maple in a straight-plank run. Joints are staggered. The grade is quiet — cathedral grain, almost no mineral streak, no character knots — so the floor does not compete with the glass or the walnut millwork.
3. Site-built open-riser treads and landings, thickness-matched to the field, with a black steel stringer left visible. Tread grain follows the walking line.
4. Flush maple-to-stone reducer at the living-room and hall tile. The two planes meet. There is no ramp and no visible lip in the photographs.
5. Satin finish so the maple reads cream in north light and a warmer honey under the linear ceiling slots and the stair LEDs.

The glass, walnut headboard wall, media wall and stone are other trades. The floor was specified to sit under them, not against them.

---

## How the maple integrates with the house

The architecture is white plaster, frameless glass, black hardware and two dark woods (walnut millwork, blackened steel). Hard maple at natural satin is the correct counterweight: it is pale enough to keep the rooms long, hard enough for a primary suite and a stair, and figured enough that a 20-foot dressing run does not go flat.

- Against **white walls and glass**, the maple supplies the only warmth in the void photographs.
- Against **walnut** (bed wall, media wall), it makes the millwork read as furniture, not as more floor.
- Against **grey stone**, the reducer is a single clean line. Same plane, different material.
- On the **stair**, matching treads mean the void is one material seen three ways: field, landing, tread. That is the whole idea of the job.

---

## Square footage and time

From the rooms in frame — primary suite, two dressing runs, upper hall and landing, two-flight stair, living room, connecting hall — the hardwood field is approximately **1,600–2,000 sq ft**. Use **~1,800 sq ft** plus the custom stair in any published figure unless a measured takeoff exists.

One week on site is consistent with Ecowoods’ published range for a 1,000–1,500 sq ft standard install, with the extra days absorbed by the open-riser stair, landings and stone reducers rather than by raw area.

---

## Honesty about the photographs

Source files are iPhone-class JPEGs at 1500 px on the short side. Every deliverable has been:

- cropped to a shared horizontal ratio so a gallery does not jump between portrait and landscape
- colour-graded to a single cream/satin maple
- upscaled to 3840×2160 (16:9) and 3600×2400 (3:2) for layout, not because new optical detail was created
- branded with the EW mark in the lower-right corner

They will hold a website, a project page and a magazine web feature. They will not replace a full-frame reshoot if the house is to run as a print cover. Construction residue that could be cropped out was cropped (commissioning note, most of the hose, part of the console cables). Objects on unfinished bed platforms were left — they are the room, not the floor.

---

## Branding

Logo file used: `https://ecowoods.ca/brand/ew-mark.png`  
Placement: lower-right, ~7.5% of frame width, light scrim so the dark monogram holds on pale maple.
