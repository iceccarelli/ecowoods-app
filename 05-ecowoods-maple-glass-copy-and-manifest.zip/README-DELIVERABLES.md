# Ecowoods — Maple & Glass Residence image pack

Four image zips + one copy zip. Download all five.

| Zip | Contents | Use |
|---|---|---|
| `01-ecowoods-maple-glass-hero-16x9-4k.zip` | 20 × 3840×2160 JPEG + contact sheet | Project heroes, full-bleed bands, magazine web |
| `02-ecowoods-maple-glass-gallery-3x2.zip` | 20 × 3600×2400 JPEG | Editorial / print-adjacent layouts |
| `03-ecowoods-maple-glass-web-1920.zip` | 20 × 1920×1080 JPEG | Site carousels, cards, OG images |
| `04-ecowoods-maple-glass-thumbs-960.zip` | 20 × 960×540 JPEG | Lazy-load thumbs, CMS previews |
| `05-ecowoods-maple-glass-copy-and-manifest.zip` | Brief, placement guide, manifest.json, this readme | Repo copy and CMS fields |

Every still is landscape, colour-matched, and carries the EW mark at lower right.

Unzip into:

```
public/images/projects/maple-glass-residence/{hero,gallery,web,thumbs}
```

Full briefing: `PROJECT-BRIEF.md`  
Exact page slots: `WEBSITE-AND-REPO-PLACEMENT.md`
