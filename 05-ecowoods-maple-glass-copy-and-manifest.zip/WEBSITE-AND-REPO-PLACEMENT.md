# Where each file goes

Repo root assumed: the Ecowoods Next/site repo.

```
public/
  images/
    projects/
      maple-glass-residence/
        hero/          ← unzip 01-hero-16x9-4k.zip here
        gallery/       ← unzip 02-gallery-3x2.zip here
        web/           ← unzip 03-web-1920.zip here
        thumbs/        ← unzip 04-thumbs.zip here
        contact-sheet-hero-16x9.jpg
        manifest.json
content/
  projects/
    maple-glass-residence.md   ← use PROJECT-BRIEF.md + captions below
```

On the live site, map the folder to the existing patterns:

| Site surface | Path | Images to use |
|---|---|---|
| Home “Recent work” card | `/` | `15` (window wash) or `01` (void) — web_1920 |
| Projects index | `/projects` | `01` as card, hover `08` |
| Project page | `/projects/maple-glass-residence` | Full 20, hero 16:9 first |
| Stairs & railings | `/` stairs service | `01, 02, 06, 07, 08` |
| Collection — Hard Maple | `/` collection tap | `13` close field, then `15, 11, 18` |
| Case study | `/case-studies/maple-glass-residence` | `01` header, `20` threshold module, `08` craft module |
| OG / social | meta image | `15` or `19` at web_1920 |

All frames are **horizontal**. Do not mix the original portrait phone files into the same carousel.

---

## Recommended on-page sequence (walkthrough)

Do not shuffle. This is the chain of rooms as a visitor walks the house.

1. `01` Void looking down — establishing
2. `02` Open risers through glass
3. `06` Stair mouth from the upper floor
4. `08` Underside of the flight — craft
5. `05` Upper landing wrapped in glass
6. `15` Primary window wash — suite hero
7. `16` Centered bed wall
8. `04` Plank field to the window
9. `11` Glass wardrobe run
10. `13` Maple grain, close
11. `09` Enfilade suite → void
12. `19` Living room under linear light
13. `18` Living field to media wall
14. `20` Stone-to-maple reducer — close the story

Hold in reserve (same job, same grade, used if a grid needs more cells): `03, 07, 10, 12, 14, 17`.

---

## Captions (site voice)

**01** Looking down a two-flight maple stair. Treads, landing and field are one species.

**02** Open-riser hard maple against a black stringer. The glass is the guard; the wood is the walk.

**06** The upper floor opens to the first tread with no change of colour or sheen.

**08** From below: the same boards, the same fastener rhythm, the grain running the walking line.

**15** Primary suite. Maple takes the window wash and stays quiet next to the walnut wall.

**13** Select hard maple, satin. This is the grade used through the house.

**18** Living room. Planks run to the media wall and stop clean at the stone.

**20** Maple and stone on one plane. The reducer is the joint, not a ramp.

---

## Filename map

Every derivative shares the same slug. Swap the folder, keep the name.

`ecowoods-maple-glass-residence-01-void-looking-down-dual-flight.jpg`  
… through …  
`ecowoods-maple-glass-residence-20-hall-stone-to-maple-reducer.jpg`

See `manifest.json` for alt text, room keys and original IMG_ numbers.
