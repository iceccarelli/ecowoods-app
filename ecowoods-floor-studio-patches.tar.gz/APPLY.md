# Ecowoods Floor Studio — the patch series

Seven patches against `iceccarelli/ecowoods-app`, base commit
`e33a968` (`fix(nav): the mega-menu you can reach, and one mobile drawer`).
They apply in order and, applied to a clean checkout of that commit, produce a
tree byte-identical to the branch they were cut from.

## Apply them

```bash
git clone https://github.com/iceccarelli/ecowoods-app.git
cd ecowoods-app
git checkout -b feat/floor-studio e33a968
git am /path/to/patches/*.patch

pnpm install
pnpm verify        # 66 guards
pnpm test:web      # 465 tests
```

`pnpm --filter @ecowoods/web exec prisma generate` first if you intend to run
`tsc --noEmit` or `next build`; neither can run without the Prisma client, and
in the sandbox this was built in `binaries.prisma.sh` is unreachable — the exact
environment `scripts/verify-client-boundary.mjs` documents itself as existing
for. Every one of the 115 `tsc` errors in that environment is a pre-existing
`@prisma/client` error, and none is in a file this series touches.

## The series

| # | Patch | Lands |
|---|---|---|
| 0001 | the catalogue of floors Ecowoods can actually lay | `lib/floor-studio/catalog.ts`; compatibility as chemistry and geometry; price as a delegation to `estimateInstalledRangeCad`; `/design` becomes a projection of the catalogue |
| 0002 | read the room, and say out loud what a photo cannot tell us | `lib/floor-studio/room.ts`; measured light, undertone, existing tone, floor quad; `UNMEASURABLE_FROM_A_PHOTO` |
| 0003 | Floor Match — a score produced by its own explanations | `lib/floor-studio/match.ts`; `recomputeScore()` reconstructs the number from the sentences |
| 0004 | lay a real floor into a real photograph | `lib/floor-studio/render.ts` + `render-canvas.ts`; exact homography, luminance preservation, occlusion mask, O(1) herringbone |
| 0005 | the design travels, and the visitor does not retype it | `lib/floor-studio/studio-config.ts`; `leadSchema.design`; `EstimateForm` reads `?design=`; `/api/leads` |
| 0006 | `/floor-studio` — the door people actually come through | the route, the client experience, CSS, chrome, homepage, sitemap, `/floor-studio.md`, `action:visualise_floor` |
| 0007 | see this in my room, on every page about a floor | `<SeeInMyRoom>` on the five species dossiers and the new-install head term; docs |

## What is in the tree afterwards

```
apps/web/lib/floor-studio/catalog.ts            + catalog.test.ts        (24)
apps/web/lib/floor-studio/room.ts               + room.test.ts           (20)
apps/web/lib/floor-studio/match.ts              + match.test.ts          (21)
apps/web/lib/floor-studio/render.ts             + render.test.ts         (24)
apps/web/lib/floor-studio/render-canvas.ts
apps/web/lib/floor-studio/studio-config.ts      + studio-config.test.ts  (24)
apps/web/app/floor-studio/page.tsx
apps/web/app/components/floor-studio/FloorStudio.tsx
apps/web/app/components/floor-studio/SeeInMyRoom.tsx
apps/web/app/md/floor-studio/route.ts
apps/web/content/constants/studio-products.ts
apps/web/tests/floor-studio.test.ts                                      (16)
docs/FLOOR_STUDIO.md
```

Touched, never rewritten: `FloorConfigurator.tsx`, `EstimateForm.tsx`,
`api/leads/route.ts`, `analytics.ts`, `funnels/index.ts`, `markdown-export.ts`,
`registry/{registry,types}.ts`, `sitemap.ts`, `next.config.js`, `Header.tsx`,
`SiteFooter.tsx`, `home-client.tsx`, `design/page.tsx`,
`guides/[slug]/page.tsx`, `hardwood-flooring-toronto/page.tsx`, `globals.css`,
`packages/shared/schemas/index.ts`, `README.md`.

Not touched at all: `content/constants/pricing.ts`, the three published bands,
`lib/floor-graph/*`, `ew-design-v1`, `/design`'s URL and querystring contract,
`/estimate`'s workflow, any NAP fact.
