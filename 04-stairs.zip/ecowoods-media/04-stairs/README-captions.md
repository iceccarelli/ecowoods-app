# Stone Cottage No. 5 — refinished oak
Ecowoods media pack. Editorial sequence: exterior → finished rooms → before chapter → craft → stairs.

These photographs are reconstructions of the original job-site frames: horizon leveled, perspective corrected, lighting refined. The rooms, floors, stairs and house are the real job. Do not present AI reconstruction as unedited documentary proof of measurements.

Suggested project slug: `stone-cottage-oak-refinish`
Suggested case-study slug: `stone-cottage-full-home-oak-refinish-stairs`

---

## Where these files go in the repo
Repo: https://github.com/iceccarelli/ecowoods-app
Live site: https://ecowoods.ca

The marketing site lives in `apps/web`.

### 1. Projects gallery (primary)
Site page: https://ecowoods.ca/projects  
Code: `apps/web/app/projects/`, `apps/web/app/projects/[slug]/page.tsx`, `apps/web/lib/projects.ts`, `apps/web/app/components/project/BeforeAfterPair.tsx`, `apps/web/app/components/project/ChapterFilm.tsx`

Projects on Ecowoods are “two chapters, bare then finished.”  
Upload path to create:

```
apps/web/public/projects/stone-cottage-oak-refinish/
  01-exterior-stone-cottage-red-door.jpg
  chapter-bare/   ← contents of 02-before/
  chapter-finished/ ← contents of 01-hero-after/ minus exterior, plus process/stairs if wanted
```

Register the slug in `apps/web/lib/projects.ts` (or the existing projects content module) with:
- title: Stone cottage, red oak refinish
- neighbourhood only (do not publish the street number 5)
- chapters: Bare / Finished
- services: refinishing, dust-free sanding, stair refinishing

### 2. Case studies (if you have measurements)
Site page: https://ecowoods.ca/case-studies  
Code: `apps/web/content/case-studies/*.mdx`, `apps/web/app/case-studies/`

Add `apps/web/content/case-studies/stone-cottage-full-home-oak-refinish-stairs.mdx`  
Images referenced from `/projects/stone-cottage-oak-refinish/...`  
Only publish as a case study if substrate, species confirmation, moisture readings and area are on file. The public site treats case studies as measured jobs, not mood boards.

### 3. Homepage Proof slider
Site: https://ecowoods.ca/  “Proof” before/after  
Data: `apps/web/app/data/slider-images.ts` and `BeforeAfterPair.tsx`

Best pair:
- Before: `02-before/02-before-sage-room-worn-oak.jpg`
- After:  `01-hero-after/05-after-sage-room-open-plan.jpg`

Second pair:
- Before: `02-before/01-before-sunlit-yellow-hallway.jpg`
- After:  `01-hero-after/02-after-sunlit-yellow-hallway.jpg`

### 4. Floor collection / species visuals
Data: `apps/web/app/data/floor-images.ts`  
Hero after shots 03–07 can support a “red oak strip, satin/semi-gloss, straight plank” collection tile.

### 5. Stairs service page
Site: https://ecowoods.ca/hardwood-stairs-toronto  
Use:
- `04-stairs/01-stairs-treads-stripped-floor-finished.jpg` (craft, mid-job)
- `02-before/07-before-stair-run-peeling-treads.jpg`
- `02-before/08-before-stair-looking-down.jpg`

### 6. The Craft / process
Kitchen cabinet boxes on a finished floor:
`03-process-craft/01-process-kitchen-cabinets-on-finished-oak.jpg`  
Shows the floor completed before the kitchen lands — useful for “sequence of trades” and dust-containment stories.

### 7. Job platform / media API (operations, not marketing)
`apps/web/app/api/v1/media/`  
`apps/web/lib/floor-graph/photo-storage.ts`  
`apps/web/app/api/photo-triage/route.ts`

Attach the original + enhanced set to the actual job record in the admin project so the crew and estimator can use them. Do not put the house number on public pages.

### 8. Public static convention already in the repo
Existing public galleries use kebab-case plus a role suffix, e.g.  
`apps/web/public/gallery-machines/drum-sander-01-inuse.webp`

Match that pattern. Convert to `.webp` on ingest if the site pipeline expects it (`apps/web/lib/image-compress.ts`).

---

## Instagram / LinkedIn captions

Tone: quiet luxury, craft, Toronto. No hype. No invented square footage.

### 01-exterior-stone-cottage-red-door.jpg
IG: Spring light on a stone cottage. The work is inside — original oak, sanded and finished to a single sheen from the threshold to the stairs.  
#Ecowoods #TorontoHardwood #HeritageHome

LI: Establishing shot for a full-home oak refinish in a stone cottage. The public record of this job belongs with the finished rooms and the stair sequence, not with the street number.

### 02-after-sunlit-yellow-hallway.jpg
IG: A narrow hall. One window. The floor is what carries the light.  
#HardwoodRefinishing #OakFloors

LI: Finished strip oak in a service hallway. This is the after frame for the matching bare-chapter photograph in pack 02.

### 03-after-sage-room-french-door-sheen.jpg
IG: Sage walls. French door. Red oak that finally reads as one surface.  
#FloorFinish #TorontoHomes

LI: Hero room after full sand and finish. Use on the project finished chapter and as a collection tile for straight-lay red oak.

### 04-after-sage-room-window-light.jpg
IG: Same room, different hour of light. The finish should hold both.

LI: Alternate hero. Good Open Graph still for the project page.

### 05-after-sage-room-open-plan.jpg
IG: Empty room. Continuous grain. This is the after of the dusty sage-room before.

LI: Primary before/after pair with `02-before-sage-room-worn-oak.jpg`. Homepage Proof slider candidate.

### 06-after-window-alcove-closets.jpg
IG: Window alcove, original closets, new floor. The architecture stayed. The floor did not.

LI: Bedroom/alcove after. Useful on the project page grid, not the homepage.

### 07-after-grey-room-chair-rail.jpg
IG: Grey room, chair rail, long heater — and a floor that finally sits still in the light.

LI: Second principal room after. Strong centered composition for LinkedIn.

### 08-after-louvered-closets-grey-room.jpg
IG: Louvered closets. Quiet grey. Oak running the length of the room.

LI: Storage wall + finished floor. Good for “whole-home continuity” carousel slide 4.

### 09-after-enfilade-through-doorway.jpg
IG: One floor, two rooms, one line.

LI: Enfilade after. Shows the floor continuing through the door — the argument for refinishing the house as one job.

### 10-after-kitchen-threshold-new-oak.jpg
IG: The kitchen is still a shell. The floor is already finished. Sequence matters.

LI: Threshold after. Pairs with the process shot of cabinet boxes on the finished oak.

### 01-before-sunlit-yellow-hallway.jpg
IG: Same hall. Before the sanders. The light was always there.

LI: Bare chapter. Pair with finished hallway 02.

### 02-before-sage-room-worn-oak.jpg
IG: Wear, haze, traffic paths. This is the honest start.

LI: Primary before frame for the homepage slider.

### 03-before-sage-room-through-door.jpg
IG: Through the door, the floor is still waiting.

LI: Secondary before. Use in the project bare chapter, not the slider.

### 04-before-kitchen-dusty-oak.jpg
IG: Kitchen floor before. Cabinets in, finish not yet.

LI: Kitchen bare chapter. Pair with process pack 03.

### 05-before-kitchen-cabinets-raw-floor.jpg
IG: Boxes in. Floor unfinished. The order of trades is the story.

LI: Process before. Keep in the craft chapter.

### 06-before-stair-hall-dust.jpg
IG: Stair and hall before. Two assemblies, one house.

LI: Stair approach before. Use on the stairs service page.

### 07-before-stair-run-peeling-treads.jpg
IG: Paint failing on the treads. This is why stairs give a job away.

LI: Stair before. Pair with mid-job stripped treads in pack 04.

### 08-before-stair-looking-down.jpg
IG: Looking down a worn run. Every tread is a record.

LI: Overhead before. Strong LinkedIn document shot.

### 01-process-kitchen-cabinets-on-finished-oak.jpg
IG: Floor first. Kitchen second. The sheen is already in.

LI: Craft still. Shows finished oak under cabinet installation — useful for scheduling and protection narratives.

### 01-stairs-treads-stripped-floor-finished.jpg
IG: Hall finished. Treads stripped. The stair is next.

LI: Mid-job stair. Best image for the hardwood stairs service page and for a “one house, two paces” carousel.

---

## Suggested public carousel order (Ferrari / Burberry edit)
1. Exterior cottage  
2. Sunlit finished hallway  
3. Sage room sheen  
4. Grey room centered  
5. Enfilade through doorway  
6. Kitchen boxes on finished oak  
7. Stairs mid-strip  
8. One before (sage room worn) as the last beat, not the first
