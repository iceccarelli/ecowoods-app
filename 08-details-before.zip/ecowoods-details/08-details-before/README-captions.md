# Stone cottage — detail plates
Companion pack to zips `01-hero-after` through `04-stairs`.
Those are the wide chapter stills. These are the close plates: one delight per frame.

Do not replace the wide set. Pair them.
Wide shot = room. Detail plate = the sentence the room is making.

Job: whole-home strip-hardwood refinish, kitchen still in boxes, stairs mid-strip.
Services these plates argue for (Ecowoods Inc.):
- Hardwood floor refinishing / full sand & finish
- Dust-free sanding (the before haze is why containment exists)
- Stair refinishing (treads that have to match a finished hall)
- Work in an occupied / in-progress house (heaters, closets, HVAC, cabinet boxes)

Not an installation of new boards. Not an inlay job. Do not caption them as herringbone, walnut, or wide plank.

Public copy still follows repo law: no civic address in titles, no species claim unless registered, no invented sqft. The door plate shows the real oval plaque; do not write “No. 5” into page titles or slugs.

---

## How this integrates with the first zips

| Wide still (packs 01–04) | Detail plate (packs 05–08) | What the detail proves |
|---|---|---|
| 01-exterior-stone-cottage-red-door | 05/01 stone-arch-red-door | Heritage house. The work is inside. |
| 02-after-sunlit-yellow-hallway | 06/01 sunshaft-on-sheen | Finish holding daylight. |
| 03-after-sage-room-french-door-sheen | 06/02 door-grid-in-sheen | Sheen as a controlled surface. |
| 05-after-sage-room-open-plan | 06/03 strip-end-joint-grain | Tight joints, even colour, open grain after sand. |
| 05-after-sage-room-open-plan | 06/04 baseboard-reveal-line | Clean cut to existing trim. |
| 09-after-enfilade-through-doorway | 06/05 floor-through-doorway | One floor through two rooms. |
| 06-after-window-alcove-closets | 06/06 window-bars-on-boards | Light as the test of the finish. |
| 08-after-louvered-closets-grey-room | 06/07 floor-at-louvered-closets | Continuity under a storage wall. |
| 07-after-grey-room-chair-rail | 06/08 floor-at-baseboard-heater | Refinish around existing heat. |
| 03-after-sage-room-french-door-sheen | 06/09 register-reflected-in-finish | Cut clean around HVAC. |
| 10-after-kitchen-threshold-new-oak | 06/10 finished-floor-raw-drywall | Floor done while walls still open. |
| 03-process kitchen cabinets on oak | 07/01 cabinet-box-over-finished-floor | Sequence of trades: floor first. |
| 04-stairs stripped / hall finished | 07/02 curved-tread-paint-vs-hall | Two paces in one house. |
| same | 07/03 stripped-stair-nosing | The nosing after the sander. |
| 02-before yellow hallway | 08/01 hallway-oval-patch-wear | Old repair still visible before sand. |
| 02-before sage worn | 08/02 tired-finish-haze-scratches | Why the floor was sanded. |
| 02-before kitchen dusty | 08/03 kitchen-dust-under-cabinet-feet | Kitchen arriving on a tired floor. |
| 02-before peeling treads | 08/04 stair-peeling-paint-layers | Stairs give a job away. |
| 02-before looking down | 08/05 worn-tread-traffic-grain | Traffic written into the wood. |

Repo placement (same project as the wide stills):

```
apps/web/public/proof/stone-cottage-strip-refinish/details/
```

Do not mix these into `ch1/` / `ch2/` as if they were the chapter cards. Add a third role only if the Project type is extended. Safer: use them as
- Ken Burns / library close-ups linked from the matching wide still
- Instagram / LinkedIn feature carousel
- Stairs service page and refinishing service page
- Collection tile for “straight strip, satin-to-gloss sheen” — describe what the camera sees, not a species

Homepage slider stays the wide sage-room pair. Details are too tight for a before/after wipe.

---

## Instagram carousel (10 frames)
Order is the story. Caption the carousel once; each slide can carry the short line.

1. 05/01 stone-arch-red-door  
   The house is older than the finish. The work starts inside.
2. 08/02 tired-finish-haze-scratches  
   This is a tired film, not a tired house.
3. 08/01 hallway-oval-patch-wear  
   An old patch in the hall. Sanding has to take the whole floor with it.
4. 08/04 stair-peeling-paint-layers  
   Stairs are where a refinish is judged.
5. 06/01 sunshaft-on-sheen  
   Same hall. The finish is what holds the light.
6. 06/02 door-grid-in-sheen  
   A door only reflects like this when the surface is even.
7. 06/03 strip-end-joint-grain  
   Joints tight. Colour even. Grain open again.
8. 07/01 cabinet-box-over-finished-floor  
   Floor first. Kitchen second.
9. 07/03 stripped-stair-nosing  
   Hall done. Treads next.
10. 06/05 floor-through-doorway  
    One house. One floor.

Hashtags (use sparingly): #Ecowoods #TorontoHardwood #FloorRefinishing #DustFreeSanding #StairRefinishing

---

## LinkedIn feature (5 frames + one paragraph)
Use 08/02 → 06/01 → 07/01 → 07/02 → 06/04

Body:
> Most Toronto main floors need this every 7–10 years: sand to bare wood, rebuild the finish, leave the architecture alone. This cottage was photographed twice — worn film and traffic paths, then the same rooms after the finish. The kitchen boxes arrived on a floor that was already done. The hall was finished while the stair was still mid-strip. That sequence is the job.
>
> Ecowoods Inc. — refinishing, dust-free sanding, stair refinishing. Fixed price in writing. Toronto and the GTA.

Do not attach square footage or a species.

---

## Captions per file

### 05-details-house
**01-detail-stone-arch-red-door.jpg**  
Feature: fieldstone arch and painted door.  
IG: The cottage is the context. The floor is the work.  
LI: Establishing plate. Heritage envelope, interior refinish.  
Site: project page opener only. Do not title the page with the house number visible on the plaque.

### 06-details-finish
**01-detail-sunshaft-on-sheen.jpg**  
Feature: daylight raking across a finished strip floor.  
Service: refinishing / finish quality.  
IG: The finish is what keeps the sun.

**02-detail-door-grid-in-sheen.jpg**  
Feature: french-door lights mirrored in the film.  
Service: sand & finish, even sheen.  
IG: If the door draws itself on the floor, the surface is doing its job.

**03-detail-strip-end-joint-grain.jpg**  
Feature: end-match joint and open grain after sanding.  
Service: full sand, not a screen-and-recoat.  
IG: The joint is the quiet proof.

**04-detail-baseboard-reveal-line.jpg**  
Feature: floor meeting existing baseboard.  
Service: refinishing around finished trim.  
IG: The line that says the sander stopped where it should.

**05-detail-floor-through-doorway.jpg**  
Feature: boards continuing through the opening.  
Service: whole-home refinish as one colour.  
IG: Two rooms. One floor.

**06-detail-window-bars-on-boards.jpg**  
Feature: window mullions laid as light on the boards.  
Service: finish that reads in changing light.  
IG: Morning is the inspection.

**07-detail-floor-at-louvered-closets.jpg**  
Feature: finished strip under a closet wall.  
Service: occupied-house refinish.  
IG: The storage wall stayed. The floor did not.

**08-detail-floor-at-baseboard-heater.jpg**  
Feature: heater left in place, floor renewed under it.  
Service: refinishing around existing mechanicals.  
IG: Heat stays. The film does not.

**09-detail-register-reflected-in-finish.jpg**  
Feature: floor register and its reflection.  
Service: edges, vents, the work a drum sander cannot fake.  
IG: The grille only reflects when the edge work is done.

**10-detail-finished-floor-raw-drywall.jpg**  
Feature: completed floor against open drywall.  
Service: sequencing with other trades.  
IG: The floor can finish before the walls do.

### 07-details-craft
**01-detail-cabinet-box-over-finished-floor.jpg**  
Feature: raw cabinet box, copper, work light, finished oak beneath.  
Service: refinishing ahead of kitchen set.  
IG: Floor first. Then the kitchen.

**02-detail-curved-tread-paint-vs-finished-hall.jpg**  
Feature: curved first tread, paint on the riser, finished hall at its foot.  
Service: stair refinishing.  
IG: The hall is done. The stair is not. That is the honest middle of the job.

**03-detail-stripped-stair-nosing.jpg**  
Feature: sanded nosing, raw wood, paint remaining on the riser.  
Service: stair sanding.  
IG: A nosing after the machine. This is the part that has to match the floor.

### 08-details-before
**01-detail-hallway-oval-patch-wear.jpg**  
Feature: oval patch in the worn hall.  
Service: restoration / full sand (a patch disappears only if the whole floor is cut back).  
IG: Someone repaired this once. The next pass has to take all of it.

**02-detail-tired-finish-haze-scratches.jpg**  
Feature: haze and hairline scratch in the old film.  
Service: refinishing vs screen-and-recoat. This wear is through the film.  
IG: Greying and scratch — the usual reason a main floor comes back.

**03-detail-kitchen-dust-under-cabinet-feet.jpg**  
Feature: dusty kitchen boards under cabinet feet.  
Service: refinish timing relative to kitchen.  
IG: The boxes arrived before the floor was ready. The next chapter reverses that.

**04-detail-stair-peeling-paint-layers.jpg**  
Feature: stacked paint failure on a stair riser.  
Service: stair refinishing.  
IG: Paint failing in layers. This is why stairs are quoted separately.

**05-detail-worn-tread-traffic-grain.jpg**  
Feature: compressed, shiny-dark wear in a tread.  
Service: stair refinishing / restoration.  
IG: Traffic writes. Sanding reads it back.

---

## Agent note
When ingesting with the earlier brief:
- Keep slug `stone-cottage-strip-refinish`
- Wide stills = chapter interiors
- These files = `/proof/stone-cottage-strip-refinish/details/{filename}.webp`
- Pair each detail to its wide still in a caption or `pairs`-like `anchor` if you extend the type
- Convert to WebP the same way
- Do not feed detail crops into the homepage slider
- Do not publish the hallucinated “21” frame (it was discarded)
