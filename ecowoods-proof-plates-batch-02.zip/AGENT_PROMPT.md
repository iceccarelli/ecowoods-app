# Agent prompt — Ecowoods before/after sliders

Copy everything below the line into the agent that will implement this.

---

You are working in the Ecowoods monorepo (`iceccarelli/ecowoods-app`), live site https://ecowoods.ca.

## Mission

Ship **one** reusable before/after slider and mount it only where the placement maps say. Do not invent new routes. Do not write a second gallery. Do not reuse `IllustrationPair` (that component cross-fades diagrams and will crop the floor).

Two zips have been prepared to unzip at the **repo root**:

1. `ecowoods-proof-plates.zip` — batch 01 plates + `apps/web/app/data/proof-plates.ts`
2. `ecowoods-proof-plates-batch-02.zip` — batch 02 plates + `apps/web/app/data/proof-plates-batch-02.ts`

After both are unzipped, files live at `apps/web/public/proof/*.webp` and are served at `/proof/<file>.webp`.

## What this company is

Hardwood installation, refinishing, dust-free sanding, stairs, inlays, commercial work in Toronto and the GTA. Brand voice is measured and checkable: published price bands, published MVTR readings, salaried crews, no subcontractors. Source comments in `apps/web/app/home-client.tsx` and `JobCard.tsx` say **no stock photography** and **none of the case studies publishes an image**. The plates in `/public/proof` are **layout comps**. Caption them as visualizations of the work. Never as “this exact occupied unit” until first-party photos replace the files.

## What already exists (do not duplicate)

- `apps/web/app/home-client.tsx` ~557 — `{/* 4 · FIRST-PARTY PROOF */}` then `<JobCardRail />`
- `apps/web/app/components/JobCard.tsx` — `imageSlot` is wired and empty
- `apps/web/app/components/EvidenceRail.tsx` — text case-study cards, kicker already `"Proof, with the numbers"`
- `apps/web/app/components/IllustrationPair.tsx` — diagrams only
- `apps/web/app/components/FloorCatalog.tsx` + `public/gallery/` — species beauty shots, not before/after
- Case studies: `forest-hill-walnut-wide-plank-color-stability`, `distillery-district-victorian-condo`, `yorkville-loft-basement-conversion-moisture-mitigation`, `midtown-townhouse-three-level-transition`, `rosedale-estate-stairs-radiant-heat`
- Head terms: `/hardwood-flooring-toronto`, `/hardwood-floor-refinishing-toronto`, `/hardwood-stairs-toronto`, `/hardwood-floor-problems-toronto`, `/services/dust-free-sanding`, `/realtors`, `/commercial`, `/design`, `/library`, `/service-areas/*`

## What to build

A single client component, e.g. `apps/web/app/components/BeforeAfterSlider.tsx`.

```ts
type BeforeAfterSliderProps = {
  beforeSrc: string;
  afterSrc: string;
  beforeAlt: string;
  afterAlt: string;
  leftHandle?: 'before' | 'during';
  rightHandle?: 'after';
  kicker?: string;
  headline: string;
  factline?: string;
  instruction?: string;
  ctaHref?: string;
  ctaLabel?: string;
};
```

Behaviour:

- Drag a circular handle horizontally. Left reveals BEFORE, right reveals AFTER. Same as a curtain.
- Hover may nudge the handle 8–12px so the floor “breathes.” No autoplay.
- Keyboard: ArrowLeft / ArrowRight move the split.
- `prefers-reduced-motion: reduce` → static 50/50, no animation.
- Mobile: same drag, larger hit target.
- Semantic: `<figure>` + `<figcaption>`. Both images must remain in the DOM (not display:none) so crawlers and `llms.txt` can see both.
- Images: next/image or the site’s existing `getImage` helper if it supports `/proof`. Do not put these files through the illustration pipeline.

Data: import from `apps/web/app/data/proof-plates.ts`. Merge batch 02 into that file so there is **one** registry. Use `proofSrc(file)` for URLs. Add batch 02 keys to `JOBCARD_AFTER_STILL`.

If the repo has `scripts/verify-images.mjs`, register `/proof` plates the same way illustrations are registered so a missing file fails the build.

## Exact mount points

Mount the slider as a block, full content width, rounded frame, labels “Before” / “After” (or “During” / “After”) in the corners. Keep existing page copy. Do not delete EvidenceRail or JobCards — the slider sits **above** them.

### Batch 01 (already specified)

| Plate | Mount |
|---|---|
| `richmondHillMaple` | `/` immediately after `<PricingSection />` and before `<JobCardRail />`. Also `/hardwood-floor-refinishing-toronto` under the H1/price CTA. Also `/service-areas/richmond-hill`. |
| `forestHillWalnut` | `/hardwood-flooring-toronto` after the cost bands. Case study page + JobCard `imageSlot` AFTER still. `/service-areas/forest-hill`. |
| `rosedaleStairs` | `/hardwood-stairs-toronto`. Case study + `/service-areas/rosedale`. |
| `dustFreeOccupied` | `/services/dust-free-sanding` under “what dust-free actually means.” Left handle **During**. Also `/commercial`. |
| `realtorPrelist` | `/realtors` under the 3-day pre-list narrative. |
| `distilleryLoft` | Distillery case study. `/service-areas` “Proof, with the numbers.” `/commercial`. |
| `problemsCupping` | `/hardwood-floor-problems-toronto` only. Board-level crop. Not a homepage hero. |

### Batch 02 (this zip)

| Plate | Mount |
|---|---|
| `yorkvilleBasement` | `/case-studies/yorkville-loft-basement-conversion-moisture-mitigation` hero. `/service-areas/yorkville`. Optional second slider on `/hardwood-flooring-toronto` if that page does not already use Forest Hill. JobCard `imageSlot` AFTER still. |
| `midtownTownhouse` | `/case-studies/midtown-townhouse-three-level-transition` hero. `/service-areas/midtown-toronto`. Homepage JobCard for this slug. Secondary on `/hardwood-stairs-toronto` below the Rosedale slider. |
| `screenRecoat` | `/hardwood-floor-refinishing-toronto` in “Three services, one decision” / Screen & Recoat band. `/realtors` as the cheaper alternative to a full sand. Small still next to the homepage Screen & Recoat price card — not a second homepage hero. **Colour must not change.** |
| `herringboneCondo` | `/hardwood-flooring-toronto` pattern section. `/design` when pattern = herringbone. `/library` new “Before / After plates” group. Do not use this pair to sell a refinish. |
| `customInlay` | `/services` Custom Inlays & Borders card (AFTER still on the card, full slider on the service detail if that slug has a page). `/library`. `/design` as an optional extra, not the default. |
| `restorationWater` | `/hardwood-floor-problems-toronto` below the cupping slider. Restoration service page if `/services/[slug]` covers restoration. Refinish page section “if this is not quite the job.” |

### JobCards on the homepage

Fill `imageSlot` with the AFTER still for:

- `forest-hill-walnut-wide-plank-color-stability`
- `distillery-district-victorian-condo`
- `yorkville-loft-basement-conversion-moisture-mitigation`
- `midtown-townhouse-three-level-transition`
- `rosedale-estate-stairs-radiant-heat`

Do not invent customer names. Do not invent extra case studies.

### Quote / photo-triage (`/#quote`, `/#photo-triage`)

A static 50/50 still of `richmond-hill-maple` or `screen-recoat`, not a drag slider. Caption: “This is what we do with a tired maple floor.” Do not fight the form.

## Do not mount sliders here

`/papers/*`, `/guides/*` long-form (except a thumbnail linking back), `/framework`, `/glossary`, `/data`, `/authority`, `/standards`, `/team`, `/about`, `/press`, all 26 area pages that do not have a matching case study.

## Copy rules

Use the `headline`, `factline`, `beforeAlt`, `afterAlt` from the registry. Do not write “stunning transformation” or “dream floor.” Voice is the existing site: short, specific, checkable.

JSON-LD: one `ImageObject` per plate on pages that mount it. `contentUrl` = after, `thumbnailUrl` = before. Creator = Ecowoods Hardwood Flooring Inc.

Add `/proof/` URLs to `/library` and to `llms.txt` / `ai.txt` if those routes list images.

## Implementation order

1. Unzip both archives at repo root.
2. Merge batch 02 into `proof-plates.ts`. Delete nothing from batch 01.
3. Build `BeforeAfterSlider`.
4. Mount `richmondHillMaple` on homepage + refinish head-term. This is the conversion test.
5. Fill JobCard `imageSlot` AFTER stills.
6. Mount remaining P0 plates (install, dust-free, case studies).
7. Then P1 (stairs, realtors, problems, screen-recoat, yorkville, midtown).
8. Then P2 (herringbone on `/design` and `/library`, inlay, restoration).

Do not refactor PricingSection, EstimateForm, or the framework pages as part of this work.

## Quality gates

- `pnpm` typecheck and the existing `verify:*` suite must stay green.
- No invented prices, review counts, or MVTR figures on the slider captions.
- Plates marked `status: 'recapture'` may ship as comps; do not write copy that claims identical camera geometry.
- If you add files under `public/proof`, name them kebab-case `descriptor-before.webp` / `descriptor-after.webp`.

## Success

A visitor on `/` can drag maple from grey to honey without leaving the page. A visitor on refinishing can see the difference between a screen-and-recoat and a full sand. A case-study page finally has a picture. An AI crawler that cannot drag still receives both image URLs and both alts.
