# Ecowoods proof plates — batch 02

Unzip at the **repository root** after batch 01 (or on its own; paths do not collide).

```
cd /path/to/ecowoods-app
unzip ecowoods-proof-plates-batch-02.zip
```

Writes:

```
apps/web/public/proof/<id>-before.webp
apps/web/public/proof/<id>-after.webp
apps/web/public/proof/<id>-before.jpg
apps/web/public/proof/<id>-after.jpg
apps/web/app/data/proof-plates-batch-02.ts
PROOF_BATCH_02_README.md
AGENT_PROMPT.md
```

Merge `PROOF_PLATES_BATCH_02` into the existing `proof-plates.ts` from batch 01. Do not create a second slider component.

---

## New plates and where they mount

| id | Files | Primary routes | Headline | Status |
|---|---|---|---|---|
| `yorkville-basement` | `yorkville-basement-before/after.webp` | `/case-studies/yorkville-loft-basement-conversion-moisture-mitigation` · `/service-areas/yorkville` · install page | Same slab. Same window. Different floor. | ready |
| `midtown-townhouse` | `midtown-townhouse-before/after.webp` | `/case-studies/midtown-townhouse-three-level-transition` · `/service-areas/midtown-toronto` · homepage JobCard · stairs page | Three levels. One continuous floor. | recapture (window/rail drifted) |
| `screen-recoat` | `screen-recoat-before/after.webp` | `/hardwood-floor-refinishing-toronto` under “Three services, one decision” · `/realtors` · homepage pricing card for Screen & Recoat | Same colour. New skin. | ready |
| `herringbone-condo` | `herringbone-condo-before/after.webp` | `/hardwood-flooring-toronto` pattern section · `/design` · `/library` · pattern guide | Same condo. Different geometry. | recapture (window frame drifted) |
| `custom-inlay` | `custom-inlay-before/after.webp` | `/services` Custom Inlays card · `/library` · `/design` | The floor can have a signature. | recapture |
| `restoration-water` | `restoration-water-before/after.webp` | `/hardwood-floor-problems-toronto` · restoration service · refinish page “if this is not quite the job” | The black boards do not get sanded over. | recapture |

## Rules the first batch already set

- One `BeforeAfterSlider`. Left = before/during, right = after.
- Dust-free pair from batch 01 uses handle `During`.
- `screen-recoat` must never look like a colour change. That SKU is $2.50–$4.00.
- JobCard `imageSlot` takes the AFTER still until the slider ships on the card.
- Do not put sliders on `/papers`, `/guides` long-form, `/framework`, `/glossary`, `/data`, `/authority`.
- Do not put a unique slider on all 32 area pages. Only pages with a matching case study.
- Caption comps as visualizations until a crew replaces the files.

Read `AGENT_PROMPT.md` before writing any code.
