/**
 * Proof plates — BATCH 02.
 *
 * Merge these entries into apps/web/app/data/proof-plates.ts from batch 01.
 * Files live in /public/proof. Do not hard-code paths on pages.
 *
 * Layout comps until first-party photography replaces the files.
 * Do not caption a plate as a named occupied job until that swap.
 */

export type ProofHandle = 'before' | 'after' | 'during';

export type ProofPlate = {
  id: string;
  kicker: 'PROOF';
  headline: string;
  factline: string;
  instruction: string;
  leftHandle: ProofHandle;
  rightHandle: ProofHandle;
  beforeFile: string;
  afterFile: string;
  beforeAlt: string;
  afterAlt: string;
  jobSlug?: string;
  routes: readonly string[];
  ctaHref: string;
  ctaLabel: string;
  status: 'slider-ready' | 'recapture';
  sku: 'screen-recoat' | 'full-sand' | 'install' | 'stairs' | 'dust-free' | 'inlay' | 'restoration';
};

const DIR = '/proof';

export const PROOF_PLATES_BATCH_02 = {
  yorkvilleBasement: {
    id: 'yorkville-basement',
    kicker: 'PROOF',
    headline: 'Same slab. Same window. Different floor.',
    factline:
      'Yorkville loft, below grade. Moisture mitigated on the slab, then red oak with hard-maple accent stripes.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'yorkville-basement-before.webp',
    afterFile: 'yorkville-basement-after.webp',
    beforeAlt:
      'Yorkville below-grade room before hardwood: stained concrete slab, high window on the left, painted ductwork.',
    afterAlt:
      'The same below-grade room after engineered hardwood: red oak field with hard-maple accent stripes, satin finish.',
    jobSlug: 'yorkville-loft-basement-conversion-moisture-mitigation',
    routes: [
      '/case-studies/yorkville-loft-basement-conversion-moisture-mitigation',
      '/service-areas/yorkville',
      '/hardwood-flooring-toronto',
      '/services',
    ],
    ctaHref: '/case-studies/yorkville-loft-basement-conversion-moisture-mitigation',
    ctaLabel: 'Read what was measured',
    status: 'slider-ready',
    sku: 'install',
  },
  midtownTownhouse: {
    id: 'midtown-townhouse',
    kicker: 'PROOF',
    headline: 'Three levels. One continuous floor.',
    factline:
      'Midtown townhouse. Ground-floor maple meeting white oak treads and a walnut stringer. The join is the job.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'midtown-townhouse-before.webp',
    afterFile: 'midtown-townhouse-after.webp',
    beforeAlt:
      'Midtown townhouse before work: grey worn ground floor, mismatched stair treads, visible height change at the first step.',
    afterAlt:
      'The same landing after work: continuous hardwood into white oak treads with a walnut stringer and no cheap transition strip.',
    jobSlug: 'midtown-townhouse-three-level-transition',
    routes: [
      '/case-studies/midtown-townhouse-three-level-transition',
      '/service-areas/midtown-toronto',
      '/',
      '/hardwood-stairs-toronto',
    ],
    ctaHref: '/case-studies/midtown-townhouse-three-level-transition',
    ctaLabel: 'Read what was measured',
    status: 'recapture',
    sku: 'install',
  },
  screenRecoat: {
    id: 'screen-recoat',
    kicker: 'PROOF',
    headline: 'Same colour. New skin.',
    factline:
      'Screen and recoat only — $2.50–$4.00 per sq ft. Light abrasion, fresh topcoat, no full sand, no colour change.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'screen-recoat-before.webp',
    afterFile: 'screen-recoat-after.webp',
    beforeAlt:
      'Sound maple floor with dull tired finish, micro-scratches and grey traffic lanes. Colour unchanged.',
    afterAlt:
      'The same maple floor after a screen and recoat: even satin sheen, traffic lanes gone, colour unchanged.',
    routes: [
      '/hardwood-floor-refinishing-toronto',
      '/realtors',
      '/',
    ],
    ctaHref: '/hardwood-floor-refinishing-toronto',
    ctaLabel: 'Which service the floor needs',
    status: 'slider-ready',
    sku: 'screen-recoat',
  },
  herringboneCondo: {
    id: 'herringbone-condo',
    kicker: 'PROOF',
    headline: 'Same condo. Different geometry.',
    factline:
      'Builder carpet out. White oak herringbone in. Pattern install is a different buyer than a straight-lay refinish.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'herringbone-condo-before.webp',
    afterFile: 'herringbone-condo-after.webp',
    beforeAlt:
      'Empty Toronto high-rise living room with beige wall-to-wall carpet and a full-width city window.',
    afterAlt:
      'The same condo after a white oak herringbone install, natural satin finish, one lounge chair.',
    routes: [
      '/hardwood-flooring-toronto',
      '/design',
      '/guides',
      '/library',
    ],
    ctaHref: '/design',
    ctaLabel: 'Build the floor',
    status: 'recapture',
    sku: 'install',
  },
  customInlay: {
    id: 'custom-inlay',
    kicker: 'PROOF',
    headline: 'The floor can have a signature.',
    factline:
      'Custom inlay and border, routed and fitted by hand. Quoted per project, never buried in a square-foot rate.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'custom-inlay-before.webp',
    afterFile: 'custom-inlay-after.webp',
    beforeAlt:
      'Toronto foyer with a plain worn straight-lay oak floor running from the front door down the hall.',
    afterAlt:
      'The same foyer after a walnut and maple compass-rose medallion inlay framed by a contrasting border.',
    routes: ['/services', '/library', '/design'],
    ctaHref: '/services',
    ctaLabel: 'Custom inlays and borders',
    status: 'recapture',
    sku: 'inlay',
  },
  restorationWater: {
    id: 'restoration-water',
    kicker: 'PROOF',
    headline: 'The black boards do not get sanded over.',
    factline:
      'Water-damaged ends replaced, then the whole floor sanded and finished. Restoration is not a refinish with hope.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'restoration-water-before.webp',
    afterFile: 'restoration-water-after.webp',
    beforeAlt:
      'Dining room hardwood with water-blackened board ends at a patio door and peeling finish in patches.',
    afterAlt:
      'The same room after board replacement, full sand and satin finish. Damage gone, floor continuous.',
    routes: [
      '/hardwood-floor-problems-toronto',
      '/services',
      '/hardwood-floor-refinishing-toronto',
    ],
    ctaHref: '/hardwood-floor-problems-toronto',
    ctaLabel: 'Why floors fail here',
    status: 'recapture',
    sku: 'restoration',
  },
} as const satisfies Record<string, ProofPlate>;

export function proofSrc(file: string): string {
  return `${DIR}/${file}`;
}

export const JOBCARD_AFTER_STILL_BATCH_02: Record<string, string> = {
  'yorkville-loft-basement-conversion-moisture-mitigation': proofSrc(
    PROOF_PLATES_BATCH_02.yorkvilleBasement.afterFile,
  ),
  'midtown-townhouse-three-level-transition': proofSrc(
    PROOF_PLATES_BATCH_02.midtownTownhouse.afterFile,
  ),
};
