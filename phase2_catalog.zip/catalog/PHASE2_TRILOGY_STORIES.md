# Ecowoods Trilogy — Phase 2 (The Approach)

Movie-thumbnail / second frame for every Phase 1 image.

Pair each `02-` file beside its Phase 1 counterpart on the same page.

Trilogy logic: Frame 1 = the room. Frame 2 = the approach (this set). Frame 3 = the fingertip (not yet).

Official EW mark signed lower-right on every file.


## 01_homepage_hero

### 02-hero-salon-dark-oak-chandelier.jpg
**Beat title:** The Approach
From the standing room portrait to knee-height on the oak. The floor becomes a runway; chandelier and doors arrive as reflection.

### 02-hero-salon-fireplace-continuous-floor.jpg
**Beat title:** Through the Arch
Camera drops onto the plank line and walks the floor into the fireplace room. Continuous surface is the plot.

### 02-hero-geometric-parquet-french-doors.jpg
**Beat title:** Into the Pattern
The room recedes. Versailles geometry takes the foreground; the garden doors wait at the far edge.


## 07_grand_rooms

### 02-grand-paneled-oval-room-herringbone.jpg
**Beat title:** Across the Hall
Low along herringbone toward the bow of French doors. Wood and gold ceiling share one light.


## 02_custom_inlays

### 02-custom-floral-medallion-inlay.jpg
**Beat title:** The Signature
Dolly into the medallion. Flower, leaf, and scroll become the entire frame — the craftsman’s signature.

### 02-custom-geometric-border-parquet-study.jpg
**Beat title:** The Rhythm
Skim the framed oak panels. Dark borders beat like a measured score across the study.

### 02-library-chevron-wide-band-parquet.jpg
**Beat title:** Toward the Hearth
Chevron bands drive the eye into the carved fireplace. Grain direction turns with every band.

### 02-geometric-versailles-parquet-estate.jpg
**Beat title:** One Module
One complete geometric unit, close enough to read every joint. The estate room softens behind it.


## 06_craftsmanship_details

### 02-detail-geometric-inlay-borders.jpg
**Beat title:** The Crossing
Four borders meet. Joinery and grain at fingertip distance.

### 02-detail-herringbone-oak-border.jpg
**Beat title:** Block and Line
A single herringbone block against the dark border. Material, not room.


## 03_hardwood_stairs

### 02-stairs-curved-oak-iron-balustrade.jpg
**Beat title:** First Steps
The first treads and the rail beginning its climb. Stair as sculpture, not plan.

### 02-stairs-sculptural-handrail-curve.jpg
**Beat title:** The Curve
The oak handrail fills the frame as it turns. This is the second beat of the stair story: touch.

### 02-stairs-foyer-oak-treads-iron.jpg
**Beat title:** Stone to Oak
Bullnose meeting cream tile. The problem every foyer asks Ecowoods to solve, answered in one joint.

### 02-stairs-spiral-looking-down.jpg
**Beat title:** The Spiral
Tighter, overhead. Wedge treads and the circling rail as a single machine.


## 04_residential_floors

### 02-residential-dark-oak-plank-living.jpg
**Beat title:** Toward Light
Planks run the length of the house to the window. Finish sheen is the light-meter.

### 02-residential-oak-hallway-closet-transition.jpg
**Beat title:** The Threshold
Stone stops. Oak continues through the casing into the closet. Continuity as craft.

### 02-residential-herringbone-dormer-room.jpg
**Beat title:** Pointed at the Window
Herringbone V aims at the dormer. Pattern and daylight in one line.

### 02-residential-loft-kitchen-light-strip.jpg
**Beat title:** Beside the Island
Character-grade strip running under the granite. Kitchen as a hardwood room.


## 05_commercial

### 02-commercial-rickis-store-maple-strip.jpg
**Beat title:** The Aisle
Low commercial shot: maple strip carrying traffic to the counter.

### 02-commercial-rickis-storefront.jpg
**Beat title:** Crossing the Line
Mall tile ends. Hardwood begins. The store is a finished floor before it is a shop.
