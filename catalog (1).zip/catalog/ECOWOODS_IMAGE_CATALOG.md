# Ecowoods.ca — Luxury Hardwood Image System
## Asset catalog, website placement, and production notes

Official mark used on every finished file: `https://ecowoods.ca/brand/ew-mark.png`  
(local source: `/home/workdir/attachments/ew-mark-logo.png`)

The mark is placed as a small, unobtrusive signature in the lower-right margin. It is the official PNG, not redrawn.

---

## How the set is organized

| Zip / folder | Website destination |
|---|---|
| `01_homepage_hero.zip` | Homepage hero, Finished Work, The Collection |
| `02_custom_inlays.zip` | Custom Inlays & Borders, The Collection, Design |
| `03_hardwood_stairs.zip` | `/hardwood-stairs-toronto` |
| `04_residential_floors.zip` | Installation & Refinishing service pages |
| `05_commercial.zip` | `/commercial` |
| `06_craftsmanship_details.zip` | Technical library, guides, species/pattern cards |
| `07_grand_rooms.zip` | Case studies, press kit, editorial |

Each folder contains:
- Master JPEG (branded)
- `-web.jpg` lighter copy for page load

---

## 01 — Homepage hero

### hero-salon-dark-oak-chandelier.jpg
- **Where:** Homepage first-fold hero (portrait crop) · magazine cover · Instagram 4:5
- **Why:** Dark oak plank reads as a continuous architectural plane. Chandelier and French doors reflect in the finish — this is the “hardwood as architecture” image.
- **Page copy it can support:** “Hardwood Flooring in Toronto, Done Once. Done Right.”
- **Also:** `/hardwood-flooring-toronto`, Press kit

### hero-salon-fireplace-continuous-floor.jpg
- **Where:** Homepage “Finished work” band · case-study header
- **Why:** Same house, wider spatial story. Floor runs unbroken through the arch into the fireplace room.
- **Also:** `/case-studies`

### hero-geometric-parquet-french-doors.jpg
- **Where:** Homepage “The Collection” · Custom work proof
- **Why:** Versailles-style geometric oak parquet with estate French doors. Shows pattern work at room scale.
- **Also:** `/services` Custom Inlays

---

## 02 — Custom inlays & patterned floors

### custom-floral-medallion-inlay.jpg
- **Where:** Custom Inlays & Borders service page hero · Floor Studio pattern examples
- **Why:** Hand-set floral medallion, leaf border, framed field. The inlay is the protagonist.

### custom-geometric-border-parquet-study.jpg
- **Where:** Collection card “custom geometric” · case-study interior
- **Why:** Dark oak field with contrasting border frames in a paneled study. Craftsmanship at pattern scale.

### library-chevron-wide-band-parquet.jpg
- **Where:** Collection · Installation page “layouts” (chevron / diagonal band)
- **Why:** Large chevron/wide-band oak in a carved-fireplace library. Species character is readable.

### geometric-versailles-parquet-estate.jpg
- **Where:** Collection hero · Design page pattern = custom
- **Why:** Full-room Versailles parquet toward French doors. Best “look at the pattern from standing height” shot.

---

## 03 — Hardwood stairs & railings

### stairs-curved-oak-iron-balustrade.jpg
- **Where:** `/hardwood-stairs-toronto` page hero
- **Why:** Floor, treads, curved handrail, ornamental iron, and the room below in one frame. Stairs as architecture.

### stairs-sculptural-handrail-curve.jpg
- **Where:** Stairs page mid-section “handrail and newels”
- **Why:** The curved oak handrail is the subject. Tread grain is readable.

### stairs-foyer-oak-treads-iron.jpg
- **Where:** Stairs page · Installation “stairs matched to the house”
- **Why:** Oak treads rising from stone tile. Shows the floor-to-stair material transition Ecowoods is asked to solve.

### stairs-spiral-looking-down.jpg
- **Where:** Stairs page detail / process gallery
- **Why:** Geometry of a true curved stair: treads, stringer, continuous rail.

---

## 04 — Residential floors

### residential-dark-oak-plank-living.jpg
- **Where:** `/hardwood-floor-refinishing-toronto` and `/hardwood-flooring-toronto`
- **Why:** Straight-plank dark oak through connected rooms. Typical GTA house, premium finish.

### residential-oak-hallway-closet-transition.jpg
- **Where:** Installation page “transitions” · guides
- **Why:** Hardwood meeting stone, running into a closet. Real residential detail.

### residential-herringbone-dormer-room.jpg
- **Where:** Design / Collection — Herringbone, 3¼″ or 5″
- **Why:** Clean herringbone in a small dormer room. Pattern + quiet architecture.

### residential-loft-kitchen-light-strip.jpg
- **Where:** Condo / loft work · Installation
- **Why:** Light character-grade strip floor in a brick loft kitchen. Different aesthetic from the estate rooms.

---

## 05 — Commercial

### commercial-rickis-store-maple-strip.jpg
- **Where:** `/commercial` hero or project card
- **Why:** Large-area light maple/oak strip in a working retail floor. Traffic-grade commercial install.

### commercial-rickis-storefront.jpg
- **Where:** `/commercial` supporting image
- **Why:** Same project from the mall threshold. Hardwood as the finished retail plane.

---

## 06 — Craftsmanship details

### detail-geometric-inlay-borders.jpg
- **Where:** Technical library, inlay service, species cards
- **Why:** Board-scale view of field oak vs dark border inlay. Grain direction is honest.

### detail-herringbone-oak-border.jpg
- **Where:** Design pattern = Herringbone · papers / craft
- **Why:** Herringbone field with a framed border. Finish sheen is photographic, not plastic.

---

## 07 — Grand rooms / editorial

### grand-paneled-oval-room-herringbone.jpg
- **Where:** Case studies, press kit, homepage “proof” when a more palatial room is needed
- **Why:** Dark herringbone oak, carved paneling, crystal chandeliers. Highest “quiet luxury” register in the set.

---

## Color and material language (keep consistent on the site)

- Warm, not orange.
- Satin to soft-gloss finishes. No wet-look HDR.
- Grain variation preserved; boards are not cloned.
- Logo always the official EW mark, small, lower-right, generous margin.

## What was corrected in production

- Date stamps (`20 6 2008`, `27 6 2008`) removed.
- Construction tape, loose cable coils, and protective plastic removed where they were capture debris, not architecture.
- Verticals straightened; accidental phone tilt corrected.
- Noise and JPEG crush reduced; grain recovered from the source, not invented as a repeating texture.

## Source discipline

These files are restorations of real Ecowoods job photographs. Architecture, stair geometry, baluster ornament, and floor patterns were not redesigned. Where a source was soft or wide-angle, the reconstruction stays conservative.

## Recommended homepage pairing

1. **Hero (portrait / mobile):** `hero-salon-dark-oak-chandelier.jpg`
2. **Hero (landscape / desktop):** `hero-salon-fireplace-continuous-floor.jpg` or `hero-geometric-parquet-french-doors.jpg`
3. **Stairs module:** `stairs-curved-oak-iron-balustrade.jpg`
4. **Collection strip:** floral medallion + Versailles parquet + herringbone dormer + loft kitchen
5. **Commercial proof:** Ricki’s interior

---

Ecowoods Hardwood Flooring Inc. · Toronto & the GTA · ecowoods.ca
