# 04_Pickering_Maitland_Oak_Stair_Install

Pickering Maitland. Own story: oak stair install in progress, protection still down.

## Placement

| Surface | Folder | Size |
|---|---|---|
| ecowoods.ca case study / proof / carousel | `web_1920x1080/` | 1920×1080, 16:9 |
| Instagram feed / Pinterest | `social_1080x1350/` | 1080×1350, 4:5 |
| Reels / Stories / TikTok / YouTube | `04_Pickering_Maitland_Oak_Stair_Install.mp4` | 1920×1080 H.264 |

Suggested site drop: `apps/web/public/proof/04_Pickering_Maitland_Oak_Stair_Install/`

Filenames are story order. `00_` is the opening card. `99_` is the close.

Do not invent extra job photos. Every interior frame is from the site.
