# Master diagram prompt

Alias of `MASTER_TECHNICAL_ILLUSTRATION_PROMPT.md` register `d`.

Kept as a separate filename because `IMAGE_BRIEF.md` and the
production protocol both look for it.
