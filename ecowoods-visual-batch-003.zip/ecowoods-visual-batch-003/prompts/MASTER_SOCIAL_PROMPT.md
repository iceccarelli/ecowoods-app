# Master social / OG prompt

**Version:** VISUAL-PROMPT-v1.0  
**Helper:** `og()` in `apps/web/lib/images.ts`  
**Size:** 1200×630  
**Suffix:** `OG_STYLE_SUFFIX`

Existing cards (do not remake):

```
og-framework og-market og-glossary og-standards og-data
og-about og-reviews og-press og-services
```

Allowed next cards (one per system, never one per city):

```
og-corridors og-service-areas og-case-studies
og-estimate og-pricing og-commercial og-realtors og-contact
```

No lettering in the art. Headline is overlaid by the platform or
the metadata title.
