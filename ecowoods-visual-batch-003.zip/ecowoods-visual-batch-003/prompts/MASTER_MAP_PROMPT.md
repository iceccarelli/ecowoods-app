# Master corridor map prompt

**Version:** VISUAL-PROMPT-v1.0  
**Data source:** `apps/web/content/geo/corridors.ts`,
`apps/web/content/geo/markets.ts`  
**Register:** `d` (flat vector). Style suffix from `STYLE_SUFFIX`.

A corridor map is a projection of the geographic model. City names,
order, and status marks come from those files. Hand-labelled maps
are forbidden.

Show:

- the hub
- the highway the corridor follows
- member municipalities in travel order
- operational status using the same vocabulary as `/corridors`

Do not show:

- service coverage the model does not verify
- landmarks
- drive-time claims the pages do not publish
- a coloured blob that reads as "we cover this whole region"

Text inside the map: none in the `d` register. Names belong in the
HTML beside the figure, or — if a later labelled register is approved
— every name must also appear in the caption.

Proposed first slot: `corridor-system` on `/corridors`.
