# Master technical illustration prompt

**Version:** VISUAL-PROMPT-v1.0  
**Source of truth in code:** `STYLE_SUFFIX` and `DETAIL_STYLE_SUFFIX` in
`apps/web/lib/images.ts`  
**Print live prompts:** `node scripts/verify-images.mjs --prompts`

Do not fork this text into a second style. Edit the suffix in code if
the language needs to change; this file follows that suffix.

---

## Register `d` — flat vector diagram

Append to every diagram prompt:

```
Flat vector technical illustration, editorial cross-section style.
Strictly limited palette: warm cream background (#faf6ef), deep walnut
brown (#3d2b1f), copper accent (#c87e4f), one muted sage (#42704f)
only where a second material must be distinguished. Clean 2px
linework, generous negative space, no gradients, no photorealism, no
drop shadows, no perspective vanishing point — orthographic or flat
side elevation. ABSOLUTELY NO TEXT, NO LABELS, NO NUMBERS, NO ARROWS
WITH WORDS anywhere in the image. Centred composition with even
margins, safe for cropping. 16:9.
```

Labels live in the HTML caption and alt, never in the pixels.

## Register `p` — detailed educational render

Append to every detailed prompt:

```
Photorealistic technical illustration with neutral professional
lighting and high micro-detail. Real material fidelity — visible wood
grain and pores, accurate ply structure, true surface deformation
under raking light. Educational callout labels rendered sharply in
the image using the exact terminology of the accompanying caption,
set in clean sans-serif on high-contrast plates. Centred composition
with even margins. 1600x1074.
```

Every label inside the frame must also exist in `alt` and `caption`.
`verify-images.mjs` exists so a fact cannot live only in pixels.

## Register `og` — social card

```
Flat vector editorial illustration. Warm cream background (#faf6ef),
deep walnut brown (#3d2b1f), copper accent (#c87e4f). Clean linework,
generous negative space, no gradients, no photorealism. ABSOLUTELY
NO TEXT, NO LETTERING, NO NUMBERS anywhere. Subject placed
left-of-centre with clear empty space on the right for an overlaid
headline. 1200x630.
```

## Numbers

If a figure is not already published in the corpus, it is not printed
in a picture. Retired or unpublished values include invented moisture
deltas, day counts, and capture percentages the site has withdrawn.
