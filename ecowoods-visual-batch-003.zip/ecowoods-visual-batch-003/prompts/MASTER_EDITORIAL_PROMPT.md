# Master editorial / conceptual prompt

**Version:** VISUAL-PROMPT-v1.0

Use this register only for conceptual brand imagery that the page
already treats as conceptual: gallery species boards, equipment
catalogue stills that are not a specific job, atmospheric service
explanations already covered by the `p()` helper.

Do not use this register to manufacture:

- an Ecowoods project
- an Ecowoods employee
- an Ecowoods workshop
- a Toronto / Pickering / Niagara "we were here" photograph
- a before frame for a named case study

If the page needs proof, shoot it (`MASTER_PHOTOGRAPHY_PROMPT.md`).
If the page needs teaching, draw it (`MASTER_TECHNICAL_ILLUSTRATION_PROMPT.md`).
