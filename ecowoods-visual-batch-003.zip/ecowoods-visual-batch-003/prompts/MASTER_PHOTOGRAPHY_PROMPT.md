# Master photography brief

**Version:** VISUAL-PROMPT-v1.0

This is not an image-model prompt. Photographs are shot.

See `docs/visual/PHOTO_SHOT_LIST.md`.

Rules:

- Camera pointed at a real Ecowoods job, or it is not a photograph
  on this site.
- No generated interior may be ingested as `kind: 'photograph'`.
- No faces without consent.
- No landmarks used as local proof.
- No review UI, certificates, or invented signage.
- Daylight preferred. Floor visible. Human scale. Believable.
- Landing place: `public/proof`, `public/images/sliders`,
  `public/images/gbp`, or a project stills folder already wired
  through `/api/v1/media`.
