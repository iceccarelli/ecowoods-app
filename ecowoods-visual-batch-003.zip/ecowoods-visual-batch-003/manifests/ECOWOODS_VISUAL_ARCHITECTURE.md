# Ecowoods Visual Architecture

**Phase 0 audit.** Produced 2026-09-11 against `origin/main`  
**Commit:** `b206f12fdbd63bfddc777e002288c68efb5fa8f5`  
**Remote:** `https://github.com/iceccarelli/ecowoods-app`  
**Live:** `https://ecowoods.ca`

This document is the visual-systems audit the production protocol requires
before any new image is generated. It maps what already exists. It does not
propose a second architecture.

---

## 0. Decision that governs everything else

The repository already has a production-grade visual system. The correct
move is to **extend it**, not replace it.

A parallel naming law of the form `ecowoods-{surface}-{subject}-{purpose}-{variant}`
would invent a second identity for assets that already have:

- a stable id in `apps/web/lib/images.ts`
- a filename that **is** that id (`{id}.webp` under `public/illustrations/`)
- a route binding (`href`)
- alt, caption, prompt, kind, dimensions
- a build guard (`scripts/verify-images.mjs`)
- a live-URL guard (`scripts/verify-live-images.mjs`)
- rendering components (`Illustration`, `IllustrationPair`, `IllustrationThumb`)
- an agentic media API (`/api/v1/media`, `/api/v1/media/[id]`)

The existing contract is stricter than the proposed one on the single point
that matters: **a generated image may never be a photograph**.

That line is load-bearing. Thirteen other guards in this repo exist so that
every public claim traces to something real. A synthetic interior presented
as an Ecowoods job, an Ecowoods employee, or an Ecowoods workshop is the
same class of defect as a fabricated moisture reading.

---

## 1. Where assets live

| Location | Role | Count (this commit) |
| --- | --- | --- |
| `apps/web/public/illustrations/` | Canonical diagram + illustration set. Filename = manifest id. | 133 WebP |
| `apps/web/public/gallery/` | Species × pattern editorial set (room / detail / lifestyle). | 36 WebP |
| `apps/web/public/gallery-machines/` | Equipment catalogue stills + `machines.json`. | 72 WebP + JSON |
| `apps/web/public/images/sliders/` | Before/after pairs used by homepage and route sliders. JPG+WebP twins. | 16 pairs |
| `apps/web/public/images/gbp/` | Google Business Profile stills (exterior, process, branded, crew). | owner photos |
| `apps/web/public/proof/` | Case / service proof stills, including the maple-Vaughan stair film stills. | 75 files |
| `apps/web/public/films/` | Chapter films for documented projects. | 2 mp4 |
| `apps/web/app/opengraph-image.jpg` | Default OG (statically imported; deployed via `/_next/static/media`). | 1 |
| `apps/web/public/icon-192.png`, `icon-512.png` | App icons. | 2 |
| `public/brand/` (repo root) | Organisation mark (`ew-mark.png`, `ew-mark-192.png`, logo jpg). | 3 |
| `apps/mobile/frontend/assets/` | Expo icons only. | 5 |
| `docs/visual/` | Human briefs (`IMAGE_BRIEF`, `DIAGRAM_BRIEF`, slider packs). | 4 briefs |
| `docs/illustrations/PROVENANCE_IMAGE_BRIEF.md` | Provenance / grading figure brief. | 1 |

**Total raster/svg under `apps/web/public`:** 414 files.

Important deployment fact, recorded in `apps/web/app/data/slider-images.ts`
and `apps/web/lib/brand-assets.ts`: **this host does not serve
`apps/web/public` as a public origin.** Images that must resolve in
production are either:

1. statically imported so Next emits `/_next/static/media/…`, or
2. verified live by `scripts/verify-live-images.mjs`.

A path that only exists as `/illustrations/foo.webp` is not automatically
a live URL. The illustration pipeline already accounts for this
(`illustration-images.ts` static imports). Do not add a new public folder
and assume it is reachable.

---

## 2. Where metadata lives

| File | What it is |
| --- | --- |
| `apps/web/lib/images.ts` | **The illustration manifest.** 133 `SiteImage` records. Kind, status, dimensions, alt, caption, prompt, href. Helpers `p` (detailed educational render), `d` (flat vector diagram), `og` (1200×630). |
| `apps/web/app/data/illustration-images.ts` | Static `next/image` imports for every illustration, so dimensions and hashed URLs are real. |
| `apps/web/app/data/slider-images.ts` | Auto-generated static imports for every slider / proof frame. |
| `apps/web/app/data/floor-images.ts` | Gallery species set. |
| `apps/web/app/data/machine-images.ts` | Equipment stills. |
| `apps/web/app/data/hero-variants.ts` | Homepage hero *copy* variants. Not photographs. Facts interpolated from `@ecowoods/shared/constants`. |
| `apps/web/lib/brand-assets.ts` | Organisation `logo` and default OG URL, resolved by static import. |
| `apps/web/lib/schema/*` | JSON-LD. `image` / `logo` on Organization come from `brand-assets.ts`. Page OG images from `illustrationImage(...)` or project stills. |
| `apps/web/lib/registry/handlers.ts` | `handleMediaIndex` / `handleMediaProject` — photographic records of completed work, absolute URLs. Distinct from `/api/v1/evidence`. |
| `apps/web/public/gallery-machines/machines.json` | Machine gallery sidecar. |
| `apps/web/public/proof/maple-vaughan-curved-stair/MANIFEST.json` | Chapter-film stills manifest. |

There is no separate `VIS-{CATEGORY}-{NUMBER}` database. The stable id
**is** the illustration id (`service-installation`, `fig-climate-rh-bands`,
`term-anisotropic`, `og-about`, …) or the project slug in the media API.
That is the correct identity. A documentation alias table can be added;
a second runtime identity must not be.

---

## 3. Where components live

| Component | Path | Job |
| --- | --- | --- |
| `Illustration` | `apps/web/app/components/Illustration.tsx` | Renders one manifest slot. Intrinsic width/height always. Placeholder if pending. Motion: `reveal` default; `kenburns` only on scene imagery. |
| `IllustrationPair` | `apps/web/app/components/IllustrationPair.tsx` | Two related figures, one caption. |
| `IllustrationThumb` | `apps/web/app/components/IllustrationThumb.tsx` | Card thumb. Not a `<figure>`. |
| `HeroRotator` | `apps/web/app/components/HeroRotator.tsx` | Copy rotation over `HERO_VARIANTS`. `HERO_VARIANTS[0]` is the server-rendered canonical line. |
| `HeroBackdrop` | `apps/web/app/components/HeroBackdrop.tsx` | Backdrop treatment. |
| `RotatingBackground` | `apps/web/app/components/RotatingBackground.tsx` | Explicitly does **not** autoplay the hero. |
| `ProofSliderForRoute` | used by service-area pages | Binds a real before/after pair to a route. |
| `FloorCatalog` / `MachineCatalog` | `apps/web/app/components/` | Gallery surfaces. |
| `CatalogueRail` | catalogues, not photographs | PDF rail. |

Pages that already consume the illustration manifest:

- `/services/[slug]` — `SERVICE_IMAGE[slug]` + pairs
- `/papers/[slug]` — paper hero + per-section figures
- `/guides/[slug]` — guide hero + pairs
- `/glossary/[slug]` — `TERM_IMAGE[slug]`
- `/framework`, `/resources`, `/standards`, `/data`, `/market`
- `/hardwood-stairs-toronto`, `/hardwood-floor-problems-toronto`, `/hardwood-flooring-toronto`, `/hardwood-floor-refinishing-toronto`
- `/library` (visual index via `href` on every slot)

---

## 4. Two visual registers (already specified)

From `docs/visual/IMAGE_BRIEF.md` and `apps/web/lib/images.ts`:

| Register | Helper | Kind | Text in image | Use |
| --- | --- | --- | --- | --- |
| Flat vector diagram | `d()` | `diagram` | **None. Ever.** | Assemblies, matrices, sequences, comparisons |
| Detailed educational render | `p()` | `illustration` | Labels allowed, and every label is repeated in caption + alt | Defects, machines, meters, material fidelity |
| Social card | `og()` | `illustration` | None | 1200×630, subject left-of-centre |

Palette for diagrams: cream `#faf6ef`, walnut `#3d2b1f`, copper `#c87e4f`,
sage `#42704f`.

Shared style contracts live in code:

- `STYLE_SUFFIX`
- `DETAIL_STYLE_SUFFIX`
- `OG_STYLE_SUFFIX`

Every generated prompt appends one of these. `verify-images.mjs --prompts`
prints the generation brief from the same source.

---

## 5. The line that must not move

From `apps/web/lib/images.ts`:

> `kind: 'photograph'` means a camera pointed at something real. A generated
> image may be a `diagram` or an `illustration`; it may NEVER be a photograph,
> and `scripts/verify-images.mjs` fails the build on any entry that tries.

Photographic surfaces that already exist and must stay documentary:

- `/api/v1/media` project stills and films
- `public/proof/**`
- `public/images/sliders/**`
- `public/images/gbp/**`
- `public/films/**`

Team policy, already published on `/team`: there are **no names, headcounts,
tenure figures or crew photographs** on that page. Do not generate synthetic
portraits. Do not invent a team grid.

---

## 6. OG / social system

Already on disk under `public/illustrations/`:

```
og-about  og-data  og-framework  og-glossary
og-market  og-press  og-reviews  og-services  og-standards
```

Default card: `apps/web/app/opengraph-image.jpg`, imported in
`brand-assets.ts` as `OG_IMAGE_URL`.

Service, paper, guide and glossary pages generally inherit the illustration
bound to that page, or the default OG. Service-area pages currently set
OG title/description/url but **do not set a unique image** — they fall
through to the default card. That is a real, limited gap. The correct
fix is one shared geographic OG card (corridor / service-area system),
not 32 nearly identical generated interiors.

---

## 7. Geographic visual system

Source of truth for geography is **not** a picture:

- `apps/web/content/geo/corridors.ts` — 11 owner-stated corridors
- `apps/web/content/geo/markets.ts` — operational truth per market
- `apps/web/lib/geo/*` — allocation, opportunity, worthiness
- `/api/v1/corridors`, `/api/v1/locations`
- `/corridors`, `/corridors/[id]`, `/service-areas/[city]`, `/where-we-work`

Corridors currently publish as **typographic / data pages**. There is no
SVG map generated from the corridor registry. That is the one geographic
visual that is worth building, and only if labels are projected from
`CORRIDORS` + `MARKETS` so the picture cannot contradict the model.

Forbidden:

- a generated CN Tower / Distillery / Niagara Falls image used as local proof
- a Pickering hero that is just another oak living room with a different filename
- a map that paints `ADVERTISING_ONLY` or `DISCOVERY_ONLY` markets as serviced

Service-area pages already attach `ProofSliderForRoute` rather than a
unique city photograph. Keep that pattern.

---

## 8. Media API

```
GET /api/v1/media
GET /api/v1/media/[id]
```

Implemented in `apps/web/lib/registry/handlers.ts`. Public, cacheable,
absolute URLs. Carries photographic records of completed work — stills,
chapter films, before/after pairs — and states its limits in the payload
(`limits`) rather than omitting keys.

Do not create `/api/images`. Extend this.

`/api/v1/evidence` is the measured-engineering door. Do not mix the two.

---

## 9. Guards already in the build

| Script | What it protects |
| --- | --- |
| `scripts/verify-images.mjs` | Manifest integrity, kind/provenance, dimensions vs WebP headers, alt quality, prompt no-text rule, href is a real route, file exists |
| `scripts/verify-live-images.mjs` | Production image URLs resolve |
| `scripts/verify-assets.mjs` | Asset presence |
| `scripts/verify-public-assets.mjs` | Public asset contract |
| `pnpm images:brief` | Prints generation prompts from the manifest |
| `pnpm verify` | Full corpus including the above |

Any new visual work that does not pass these guards is not integrated.

---

## 10. What the IMAGE_BRIEF said was missing — current state

`docs/visual/IMAGE_BRIEF.md` (generated 2026-08-23) listed tiers of
missing art. On this commit:

| Brief claim (2026-08-23) | State at `b206f12` |
| --- | --- |
| 31 existing slots, do not remake | Still present |
| TIER 1 six service images missing | **Present.** `service-installation` … `service-stairs` on disk, wired in `SERVICE_IMAGE` |
| TIER 2 twelve paper figures missing | **Present.** `fig-*` ids on disk and bound to paper sections |
| TIER 3 five guide images missing | **Present.** |
| TIER 4 sixteen glossary terms missing | **Present.** `term-*` ids |
| TIER 5 four OG cards missing | **Present.** `og-about`, `og-reviews`, `og-press`, `og-services` |
| Provenance / grading figures | **Present.** 17 slots |

Manifest vs disk: **133 entries, 133 files, 0 missing, 0 orphans.**

The 2026-08-23 brief is historically useful and operationally stale.
New work must start from `apps/web/lib/images.ts` + this audit, not
from the brief's "they have no images at all" section.

---

## 11. Real remaining gaps (not a generation wishlist)

These are the gaps that survive after honouring the existing architecture.

1. **Corridor maps do not exist as figures.** `/corridors` is data + prose.
   A single illustration family derived from `CORRIDORS` would teach the
   operating model. Labels must be generated from the registry.
2. **Service-area OG images are generic.** One shared card for the
   service-area system is enough. Per-city photographic heroes are not.
3. **Owner photography shot list is still not a working document.**
   The IMAGE_BRIEF said `audit/PHOTO_SHOT_LIST.md` was empty. Real
   photographs of real jobs remain the highest-value missing class.
   See `docs/visual/PHOTO_SHOT_LIST.md`.
4. **Homepage hero is typographic, not a documentary floor photograph.**
   That is a brand choice already encoded in `HeroRotator`. A generated
   "Toronto interior hero" would compete with proof sliders that already
   carry the finished-floor evidence. Do not add a fake hero photograph.
5. **No team portraits, by policy.** Leave it.
6. **Illustration register does not include corridor / pricing / estimate
   / contact maps** as first-class ids. Add slots only when the page
   architecture calls for a figure and the figure teaches.
7. **`kind: 'photograph'` is unused in `IMAGES`.** All 133 slots are
   diagram or illustration. Photographs live in the media/proof/slider
   system. Keep the split. Do not fold generated art into `/api/v1/media`.

---

## 12. What this audit forbids

- Generating 32 city interiors and calling them local proof
- Generating employee faces
- Generating workshop / jobsite photographs labelled as Ecowoods work
- Generating review screenshots, certificates, licences, Google UI
- Putting a second filename scheme into production beside `{id}.webp`
- Creating `/api/images`
- Serving huge PNG masters from a new folder the host does not publish
- Baking unpublished numbers into diagrams (moisture deltas, day counts,
  capture percentages the corpus has retired)
- Remaking any of the 133 live illustration files without a recorded
  defect in that specific file

---

## 13. What "done" means for visual work after this audit

A visual change is done when:

- it has a slot in `apps/web/lib/images.ts` **or** a record in the media
  / proof / slider system, never both for the same claim
- the file is on disk at the declared dimensions
- `pnpm exec node scripts/verify-images.mjs` is clean
- the consuming page renders it through an existing component
- alt + caption + schema + markdown edition agree on what the image is
- generated work is labelled generated
- photographs have provenance
- `pnpm verify` still passes

Beautiful is not a release criterion. Agreement with the rest of the
corpus is.
