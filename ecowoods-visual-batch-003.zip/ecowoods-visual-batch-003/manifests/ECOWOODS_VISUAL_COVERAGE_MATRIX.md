# Ecowoods Visual Coverage Matrix

Audited 2026-09-11 against `origin/main` (`b206f12`).

Scoring is not "every page needs every image type". A glossary term
needs a diagram. A team page that refuses portraits needs no portraits.
A service-area page needs a bound proof slider and honest copy, not a
generated skyline.

Legend for `visual_required`:

- `hero-figure` — page already has or should have an `Illustration` hero
- `system-og` — dedicated OG card, or inherited default is acceptable
- `proof-slider` — real before/after bound to the route
- `none` — a figure would decorate rather than teach
- `forbidden` — generated documentary proof would be a truth defect

| route | visual_required | canonical asset / system | type | source | status |
| --- | --- | --- | --- | --- | --- |
| `/` | proof-slider + typographic hero | `HeroRotator` + slider imports | copy + proof | owner/slider | integrated |
| `/about` | system-og | `og-about` | illustration | generated | integrated |
| `/team` | forbidden portraits | none | — | policy | correct empty |
| `/press` | system-og | `og-press` | illustration | generated | integrated |
| `/reviews` | system-og | `og-reviews` | illustration | generated | integrated |
| `/authority` `/framework` | hero-figure | `framework-hero` + six `pillar-*` | p | generated | integrated |
| `/services` | system-og | `og-services` | illustration | generated | integrated |
| `/services/hardwood-installation` | hero-figure | `service-installation` | p | generated | integrated |
| `/services/floor-refinishing` | hero-figure | `service-refinishing` | p | generated | integrated |
| `/services/dust-free-sanding` | hero-figure | `service-dust-free` | p | generated | integrated |
| `/services/floor-restoration` | hero-figure | `service-restoration` | p | generated | integrated |
| `/services/custom-inlays` | hero-figure | `service-inlays` | p | generated | integrated |
| `/services/stair-refinishing` | hero-figure | `service-stairs` | p | generated | integrated |
| `/commercial` | system-og | default OG today | — | inherit | gap: `og-commercial` |
| `/realtors` | system-og | default OG today | — | inherit | gap: `og-realtors` |
| `/pricing` | optional diagram | none | — | — | candidate only |
| `/estimate` | optional diagram | none | — | — | candidate only |
| `/contact` | system-og | default OG today | — | inherit | gap: `og-contact` |
| `/service-areas` | system-og | default OG today | — | inherit | gap: `og-service-areas` |
| `/service-areas/*` | proof-slider | `ProofSliderForRoute` | photograph/slider | existing pairs | integrated; **no per-city generated hero** |
| `/corridors` | explanatory map | none | — | — | gap: BATCH 001 |
| `/corridors/*` | explanatory map | none | — | — | gap: BATCH 001 |
| `/where-we-work` | inherit corridors | none | — | — | same gap |
| `/case-studies` | system-og + real stills | case-study `images[]` | mix | content | gap: `og-case-studies` |
| `/case-studies/*` | real stills only | MDX `images` + proof | photograph | owner | do not invent |
| `/projects` `/projects/*` | documentary stills + films | `/api/v1/media/{slug}` | photograph | owner | integrated |
| `/blog` `/blog/*` | article image if present | article.image | varies | content | as published |
| `/guides` | thumbs | `GUIDE_THUMB` | illustration | generated | integrated |
| `/guides/*` | hero-figure | `GUIDE_IMAGE[slug]` | d/p | generated | integrated for mapped guides |
| `/papers` | thumbs | `PAPER_THUMB` | illustration | generated | integrated |
| `/papers/*` | hero + section figures | `PAPER_IMAGE` + `SECTION_IMAGE` | d/p | generated | integrated |
| `/glossary` | system-og | `og-glossary` | illustration | generated | integrated |
| `/glossary/*` | term figure where it teaches | `TERM_IMAGE[slug]` | d/p | generated | integrated for 16 terms; 8 terms correctly have none |
| `/standards` | system-og | `og-standards` | illustration | generated | integrated |
| `/data` | system-og | `og-data` | illustration | generated | integrated |
| `/market` | system-og | `og-market` | illustration | generated | integrated |
| `/library` | index of all figures | every `href` on `IMAGES` | — | generated | integrated |
| `/equipment` | machine catalogue | `gallery-machines` | stills | generated/editorial | integrated |
| `/resources` | hero-figure | `resources-hero` | p | generated | integrated |
| `/hardwood-stairs-toronto` | figure pairs | `stairs-*` | d | generated | integrated |
| `/hardwood-floor-problems-toronto` | figure pair | `symptom-cause-tree` | d | generated | integrated |
| `/hardwood-flooring-toronto` | figures | cost + climate figs | d/p | generated | integrated |
| `/hardwood-floor-refinishing-toronto` | figures | depth + wear-layer | d | generated | integrated |

---

## Coverage score (systems, not vanity density)

| System | Hero / figure | Proof | OG | Machine metadata | Notes |
| --- | --- | --- | --- | --- | --- |
| Homepage | typographic | sliders | default OG | schema org image | Correct |
| Six services | yes | sliders / proof | inherit + service figure | service schema | Strong |
| Framework / papers / guides / glossary | yes | n/a | yes for hubs | illustration href + md | Strong |
| Case studies / projects | documentary | yes | project stills | `/api/v1/media` | Strong; do not generate "missing" photos |
| Service areas | no unique hero | route slider | default | place schema, no fake photo | Correct pattern; shared OG would help |
| Corridors | none | n/a | default | corridor API | **Primary remaining figure gap** |
| Team | none | n/a | default | none | Correct empty |
| Commercial / realtors / estimate / pricing / contact | thin | some proof reuse | default | page schema | OG cards only, no fake interiors |

---

## Do-not-force list

Do not add a large hero photograph to:

- `/glossary/{term}` for commercial terms (`change-order`, `fixed-price`, …)
- `/team`
- `/pricing` (numbers + explanation, not lifestyle)
- `/reviews` (platform evidence is the proof)
- every `/service-areas/{city}`

Those empties are designed.
