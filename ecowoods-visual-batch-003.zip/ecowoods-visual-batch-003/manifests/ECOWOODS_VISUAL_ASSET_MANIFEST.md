# Ecowoods Visual Asset Manifest

Documentation index over the live illustration corpus.

**Runtime source of truth:** `apps/web/lib/images.ts`  
**Files:** `apps/web/public/illustrations/{id}.webp`  
**Machine index for photographs:** `GET /api/v1/media`  
**This file:** human table. JSON twin: `ECOWOODS_VISUAL_ASSET_MANIFEST.json`

`VIS-*` numbers are aliases. Do not import them in application code.

Commit audited: `b206f12fdbd63bfddc777e002288c68efb5fa8f5`  
Illustration slots on disk: **133 / 133**. Orphans: **0**.

---

## How to read a row

| Column | Meaning |
| --- | --- |
| Alias | Documentation id |
| Canonical id | `IMAGES[].id` — the only identity the app uses |
| File | Always `{id}.webp` |
| Register | `p` detailed render · `d` flat diagram · `og` social card |
| Route | `href` in the manifest — the page that explains the figure |
| Status | `integrated` = file on disk + wired through `Illustration` |

Every generated slot is internally `illustration` or `diagram`. None is
`photograph`. Photographs of completed work live under `public/proof`,
`public/images/sliders`, `public/images/gbp`, `public/films`, and the
media API.

---

## Counts

| Category | Slots |
| --- | --- |
| Authority / framework | 10 |
| Glossary + failure modes | 27 |
| Papers + paper heroes | 15 |
| Guides | 11 |
| OG / social | 9 |
| Services | 6 |
| Stairs figures | 8 |
| Machines figures | 8 |
| Other technical figures | 22 |
| Provenance / grading | 17 |
| **Total** | **133** |

---

## Services

| Alias | Canonical id | Register | Route |
| --- | --- | --- | --- |
| VIS-SERVICE-001 | `service-installation` | p | `/services/hardwood-installation` |
| VIS-SERVICE-002 | `service-refinishing` | p | `/services/floor-refinishing` |
| VIS-SERVICE-003 | `service-dust-free` | p | `/services/dust-free-sanding` |
| VIS-SERVICE-004 | `service-restoration` | p | `/services/floor-restoration` |
| VIS-SERVICE-005 | `service-inlays` | p | `/services/custom-inlays` |
| VIS-SERVICE-006 | `service-stairs` | p | `/services/stair-refinishing` |

## Authority

Pillars `pillar-moisture` `pillar-substrate` `pillar-specification`
`pillar-movement` `pillar-containment` `pillar-accountability`, plus
`framework-hero`, `resources-hero`, `concept-document-set` and its pair.

## Papers

Heroes: `paper-climate` `paper-craft` `paper-selection`  
Figures: `fig-climate-rh-bands` `fig-moisture-testing-sequence`
`fig-method-substrate-matrix` `fig-protocol-gates` `fig-failure-cascade`
`fig-four-machines-roles` `fig-grit-progression` `fig-planetary-blend`
`fig-screening-between-coats` `fig-full-sequence-timeline`
`fig-installed-cost-bands` `fig-species-janka`

## Guides

`guide-solid-vs-engineered` `guide-method` `guide-evaluate-quote`
`guide-ref-condo` `guide-ref-radiant` `guide-ref-refinish`
`guide-cost-toronto` `guide-choose-contractor` `guide-white-oak`
`guide-dustless` `guide-herringbone-parquet`

## Glossary / failure

Failures: `failure-cupping` `failure-crowning` `failure-gapping`
`failure-buckling` `failure-edge-peaking`  
Concepts: `concept-expansion-gap` `concept-acclimation`
`concept-mc-differential` `concept-edger-halo` `concept-acclimation-72h`  
Terms: `term-anisotropic` `term-solid-hardwood` `term-engineered`
`term-cross-ply-core` `term-wear-layer` `term-nail-down` `term-glue-down`
`term-floating` `term-subfloor` `term-radiant-heat` `term-janka`
`term-white-oak` `term-progressive-grits` `term-intercoat-screening`
`term-planetary-sander` `term-hepa-containment`

## OG

`og-framework` `og-market` `og-glossary` `og-standards` `og-data`
`og-about` `og-reviews` `og-press` `og-services`  
Plus the default statically imported `apps/web/app/opengraph-image.jpg`.

## Planned (not yet slots)

See master plan BATCH 001–002. These ids do not exist until they are
added to `lib/images.ts`:

```
corridor-system
corridor-{corridorId}
og-corridors
og-service-areas
og-case-studies
og-estimate
og-pricing
og-commercial
og-realtors
og-contact
```

---

## Photographic corpus (separate pipe)

Not listed as `VIS-*` illustration aliases on purpose.

| Tree | Role |
| --- | --- |
| `public/proof/` | Service and case proof stills, maple-Vaughan chapter stills |
| `public/images/sliders/` | 16 before/after pairs |
| `public/images/gbp/` | GBP exterior / process / branded / crew |
| `public/gallery/` | Species × pattern editorial (generated; not job proof) |
| `public/gallery-machines/` | Equipment stills |
| `public/films/` | Chapter films |
| `/api/v1/media` | Agentic index of completed-work photographs |

A gallery interior is not a case-study photograph. A slider pair that
the site presents as a project must have a real-job provenance. If that
provenance is missing, the pair is conceptual and must be labelled so
in copy — never in schema as documentary evidence.
