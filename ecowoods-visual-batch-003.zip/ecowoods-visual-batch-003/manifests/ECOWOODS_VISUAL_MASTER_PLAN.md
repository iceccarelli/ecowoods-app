# Ecowoods Visual Asset Master Plan

**Depends on:** `ECOWOODS_VISUAL_ARCHITECTURE.md` (Phase 0)  
**Date:** 2026-09-11  
**Rule:** extend the live system. Do not generate a second one.

---

## Intent

Build visual intelligence on top of the system that already ships:

```
canonical id
  → {id}.webp under public/illustrations
  → static import in illustration-images.ts
  → Illustration / IllustrationPair / IllustrationThumb
  → alt + caption + href
  → JSON-LD / OG where the page already supports it
  → verify-images.mjs
```

Photographs stay in the other pipe:

```
owner shoot
  → public/proof or public/images/sliders or project stills
  → slider-images.ts static import
  → ProofSliderForRoute / project page / /api/v1/media
  → provenance
```

Never cross the pipes.

---

## Identity

| Layer | Identity | Mutable? |
| --- | --- | --- |
| Illustration slot | `id` in `IMAGES` (e.g. `service-dust-free`) | no |
| Filename | `{id}.webp` | only with a manifest + import + guard change |
| Photograph | project slug + still id (`/api/v1/media/{slug}`) | no |
| Documentation alias | `VIS-SERVICE-003` etc. in the human manifest | yes — aliases only |

The `VIS-*` numbers in `ECOWOODS_VISUAL_ASSET_MANIFEST.json` are
**documentation aliases** for the existing ids. They are not a second
database and they are not imported by the application.

Rejected as a production filename law:

```
ecowoods-{surface}-{subject}-{purpose}-{variant}.webp
```

That scheme is useful in a brief. It is harmful as a second on-disk
identity next to 133 already-wired files.

---

## Batches

Generate nothing until the batch has a written reason, a slot, and a
quality gate. Review the batch before the next one.

### BATCH 000 — already shipped (do not regenerate)

The live illustration corpus. 133 files. Six services, paper figures,
guide figures, glossary terms, framework pillars, failure modes,
provenance/grading, OG cards.

Action: none, unless a specific file fails a quality gate with a
written defect (wrong pillar names, date stamp, unpublished number,
unreadable label, contradiction with page copy).

Known historical defect from the 2026-08-23 brief: `framework-hero`
once used unpublished pillar names and a version/date stamp. Confirm
against current file + `/framework` copy before touching it.

### BATCH 001 — corridor map family (highest remaining explanatory value)

Add illustration slots, flat-vector register (`d`), labels from
`content/geo/corridors.ts` + `content/geo/markets.ts`.

Proposed ids (new slots, existing naming law):

```
corridor-system
corridor-core-gta
corridor-400-north
corridor-401-east
corridor-407-york-peel
corridor-qew-west
corridor-403-6-west
corridor-niagara-belt
corridor-buffalo-niagara
corridor-buffalo-metro
corridor-rochester-east
corridor-cottage-north-east
```

Each map must distinguish, using the same operational vocabulary the
pages already use:

- verified operational
- indexable service-area page
- travel-by-confirmation
- not claimed

Do not invent coverage. If `operationalTruth.verifiedAt` is empty,
the mark on the map is empty.

Wire into `/corridors` and `/corridors/[id]`. Add `href` accordingly.
Do not put these files in `/api/v1/media`.

### BATCH 002 — system OG cards that are still generic

Add only where a surface has no card and a crawler would otherwise
inherit the homepage image for a different entity:

```
og-corridors
og-service-areas
og-case-studies
og-estimate
og-pricing
og-commercial
og-realtors
og-contact
```

1200×630, `og()` helper, no text in the image, subject left-of-centre.
Reuse `OG_STYLE_SUFFIX`. One card per *system*, never one per city.

### BATCH 003 — owner photography (cannot be generated)

Execute `docs/visual/PHOTO_SHOT_LIST.md` on real jobs.

Landing places already exist: `public/proof/`, `public/images/sliders/`,
project stills, GBP folders. After ingest:

- run the slider import generator
- add provenance
- expose through `/api/v1/media` if it is a completed-work record
- never mark `kind: 'photograph'` on a generated file

### BATCH 004 — page-specific diagrams only where the page teaches a structure

Candidates, each requiring a written "what does this explain" line
before a prompt is written:

```
pricing-service-levels          → /pricing
estimate-measurement-process    → /estimate
```

Skip if the page is already clear in prose and a figure would only
decorate. The pricing page in particular must not grow luxury interiors
beside numbers.

### BATCH 005 — quality + discovery, not more pictures

- Confirm every `href` in `IMAGES` is still a live route
- Confirm service-area sliders bind the right pair to the right route
- Confirm Organisation `logo` + `image` still resolve
- Add tests only for new slots
- Do not add a second media API

---

## Generation rules for any new slot

1. Add the slot to `apps/web/lib/images.ts` first, with real alt, caption,
   prompt, href, and dimensions. Status `pending` if the file is not on
   disk yet. The component already renders a reserved box.
2. Generate against the prompt that will be committed. The prompt is
   provenance.
3. Convert to WebP. Honour the existing byte budget (IMAGE_BRIEF:
   ≤ 90 KB per megapixel after conversion; 1600px minimum on the long
   edge for new masters before trim).
4. Measure true content box; write `DIMS[id]`.
5. Add the static import to `illustration-images.ts`.
6. Render through `Illustration` / `IllustrationPair`.
7. Run `node scripts/verify-images.mjs`.
8. Do not ship a batch that remakes an existing id "because a new
   prompt is prettier".

---

## Quality gate (every new file)

```
REALISM OR CLARITY       appropriate to its register
BRAND FIT                cream / walnut / copper / sage for diagrams
TECHNICAL CORRECTNESS    no unpublished numbers
SEMANTIC ACCURACY        agrees with page + schema + markdown
ACCESSIBILITY            alt describes information; diagram text is in HTML
PERFORMANCE              intrinsic dimensions; no CLS
NO FABRICATION           not a fake job, person, place, review, licence
NO AI ARTIFACTS          no warped tools, nonsense lettering, plastic grain
CORRECT NAMING           filename === id
CORRECT ROUTE            href is real
```

Reject and regenerate the single file. Do not batch-replace the corpus.

---

## Explicitly out of scope

- Per-municipality generated heroes
- Synthetic staff
- Synthetic workshop / van / storefront presented as fact
- Fake before/after for a named case study
- Luxury-stock photography on `/pricing`
- A new `docs/visual/ECOWOODS_VISUAL_ASSET_MANIFEST.json` becoming
  the runtime source of truth (the runtime source is `lib/images.ts`)

---

## Release sequence

```
AUDIT (this folder)
  → PLAN (this file)
  → ADD SLOT
  → GENERATE ONE BATCH
  → QC
  → REGISTER (images.ts + static import)
  → INTEGRATE (existing component)
  → TEST (verify-images + page test if needed)
  → VERIFY (pnpm verify)
  → ZIP only the new batch, not the whole public tree
  → NEXT BATCH
```

Final ZIP, when a batch actually produces files:

```
artifacts/visual/ecowoods-visual-batch-00N.zip
```

containing only `/images`, `/prompts`, `/manifests`, `/metadata`,
`/previews` for that batch.
