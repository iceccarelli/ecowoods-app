# Photo shot list — real jobs only

Generated images cannot replace this list. `kind: 'photograph'` in
`apps/web/lib/images.ts` requires a provenance naming a real shoot.
`/api/v1/media` is the public door for those frames.

Shoot on the next three jobs. Handheld is fine. Locked-tripod
before/after is better when the room allows it; if the camera moved,
the site already knows how to show a pair side by side without a wipe
(`handlers.ts` says so out loud).

Do not stage company signage that is not there. Do not add frames
that include other people's faces without written consent.

---

## Every job, if the room allows it

1. Subfloor before anything is laid or sanded — the thing the method
   decision came from.
2. Both moisture meters in the actual room, displays readable, no
   invented numbers after the fact. The values in the photograph are
   the values that go in the estimate.
3. Expansion gap at a wall, before the baseboard goes back on.
4. The same gap at a fixed object (column, hearth, kitchen island)
   if one exists.
5. Containment at the doorway — zip wall, hose run, collector.
6. Each of the four machines actually in the room: belt, edger,
   planetary, buffer. One frame per machine is enough.
7. Edger at the baseboard, field behind it.
8. Finish being applied — the real applicator, the real sheen.
9. Occupied-house proof if the house stayed liveable: furniture in
   the next room, collector in this one.
10. Finished room, daylight, floor as the subject, people optional
    and secondary.
11. One material close-up: grain, edge, transition, nosing, or inlay
    seam.
12. Exterior only if it is actually this property and you have the
    right to publish it. No landmark hunting.

## Stairs jobs

13. Treads mid-sand, risers masked.
14. Nosing profile before and after.
15. Well / overhead if the architecture is the point (see maple-Vaughan
    chapter stills for the existing pattern).

## Restoration jobs

16. The damaged section before any board comes out.
17. Replacement board dry-fit against surrounding grain.
18. The same frame after finish. Restoration is indistinguishable
    work, so the "before" is what makes the photograph evidence.

## Inlay / pattern jobs

19. Mitred corner or medallion at an angle that shows the seam.
20. Field / border species contrast.

## What not to shoot for the site

- Crew faces as a stand-in for `/team`
- A van in front of a landmark
- A phone screenshot of a review
- A certificate on a wall
- Anyone else's floor

## Ingest

Land files under the existing trees, not a new one:

```
apps/web/public/proof/{project-slug}/
apps/web/public/images/sliders/
apps/web/public/images/gbp/...
```

Then:

- regenerate `apps/web/app/data/slider-images.ts` with the existing script
- add the project to the media registry if it is completed work
- write provenance (job, date, what the frame shows)
- never change `kind` on a generated illustration to `photograph`
