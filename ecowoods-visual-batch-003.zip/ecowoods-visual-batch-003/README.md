Ecowoods visual batch 003: 86 image files from production + maps.
