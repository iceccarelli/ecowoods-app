/**
 * Proof plates — before/after (and one during/after) pairs for the slider.
 *
 * Files live in /public/proof. Import this module from the slider and from
 * any page that needs a caption, alt, or route list. Do not hard-code paths.
 *
 * These plates are layout comps until first-party job photography replaces
 * the files in public/proof. Captions must not claim a named occupied job
 * until that swap happens. See home-client.tsx FIRST-PARTY PROOF comment.
 */

export type ProofHandle = 'before' | 'after' | 'during';

export type ProofPlate = {
  id: string;
  /** Short name a page heading can reuse. */
  kicker: 'PROOF';
  headline: string;
  factline: string;
  instruction: string;
  leftHandle: ProofHandle;
  rightHandle: ProofHandle;
  beforeFile: string;
  afterFile: string;
  beforeAlt: string;
  afterAlt: string;
  /** Case-study slug when one exists. */
  jobSlug?: string;
  /** Routes that should mount this slider. First entry is canonical. */
  routes: readonly string[];
  ctaHref: string;
  ctaLabel: string;
  /** Comp readiness. recapture = camera geometry drifted between frames. */
  status: 'slider-ready' | 'recapture';
};

const DIR = '/proof';

export const PROOF_PLATES = {
  richmondHillMaple: {
    id: 'richmond-hill-maple',
    kicker: 'PROOF',
    headline: 'Same maple. Same condo. Different floor.',
    factline:
      'Occupied Richmond Hill unit, dust-contained sand, waterborne two-component finish. The owner slept there.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'richmond-hill-maple-before.webp',
    afterFile: 'richmond-hill-maple-after.webp',
    beforeAlt:
      'Worn grey maple strip floor in an empty Richmond Hill condo, late-afternoon light from the left window.',
    afterAlt:
      'The same condo after a dust-contained maple refinish: honey satin waterborne finish, sheer curtains, one walnut chair.',
    routes: [
      '/',
      '/hardwood-floor-refinishing-toronto',
      '/service-areas/richmond-hill',
    ],
    ctaHref: '/case-studies',
    ctaLabel: 'See the work',
    status: 'slider-ready',
  },
  forestHillWalnut: {
    id: 'forest-hill-walnut',
    kicker: 'PROOF',
    headline: 'Same room. Same mantel. Different floor.',
    factline:
      'Forest Hill Edwardian, 8–12 inch black walnut, oil finish. The substrate was measured before a single board was laid.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'forest-hill-walnut-before.webp',
    afterFile: 'forest-hill-walnut-after.webp',
    beforeAlt:
      'Forest Hill living room before installation: plywood subfloor, blue painter tape, original dark wood mantel.',
    afterAlt:
      'The same Forest Hill room after a wide-plank black walnut install, oil-rubbed satin sheen, original mantel retained.',
    jobSlug: 'forest-hill-walnut-wide-plank-color-stability',
    routes: [
      '/hardwood-flooring-toronto',
      '/case-studies/forest-hill-walnut-wide-plank-color-stability',
      '/service-areas/forest-hill',
    ],
    ctaHref: '/case-studies/forest-hill-walnut-wide-plank-color-stability',
    ctaLabel: 'Read what was measured',
    status: 'slider-ready',
  },
  rosedaleStairs: {
    id: 'rosedale-stairs',
    kicker: 'PROOF',
    headline: 'Same flight. Same window. Different stairs.',
    factline:
      'Quoted per tread, not per square foot. The nosing is where cheap work shows.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'rosedale-stairs-before.webp',
    afterFile: 'rosedale-stairs-after.webp',
    beforeAlt:
      'Worn painted stair treads with scuffed nosings and a dull oak handrail, looking up toward a landing window.',
    afterAlt:
      'The same flight after refinishing: white oak treads, painted risers, new oak handrail and newel, landing window unchanged.',
    jobSlug: 'rosedale-estate-stairs-radiant-heat',
    routes: [
      '/hardwood-stairs-toronto',
      '/case-studies/rosedale-estate-stairs-radiant-heat',
      '/service-areas/rosedale',
    ],
    ctaHref: '/case-studies/rosedale-estate-stairs-radiant-heat',
    ctaLabel: 'Read what was measured',
    status: 'recapture',
  },
  dustFreeOccupied: {
    id: 'dust-free-occupied',
    kicker: 'PROOF',
    headline: 'They stayed home. The floor still changed.',
    factline:
      'HEPA at the tool. Zip-wall at the opening. Furniture bagged, not removed.',
    instruction: 'Drag the slider.',
    leftHandle: 'during',
    rightHandle: 'after',
    beforeFile: 'dust-free-occupied-during.webp',
    afterFile: 'dust-free-occupied-after.webp',
    beforeAlt:
      'Occupied Toronto living room mid-job: sofa and bookcase under plastic, HEPA extractor on the floor, zip-wall at the doorway.',
    afterAlt:
      'The same lived-in room after dust-free maple refinishing, furniture returned, satin floor in afternoon light.',
    routes: ['/services/dust-free-sanding', '/commercial'],
    ctaHref: '/services/dust-free-sanding',
    ctaLabel: 'What dust-free actually means',
    status: 'slider-ready',
  },
  realtorPrelist: {
    id: 'realtor-prelist',
    kicker: 'PROOF',
    headline: 'The MLS photo is taken on day three.',
    factline:
      'Orange builder stain to natural satin. Photography after the sheen settles — not before.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'realtor-prelist-before.webp',
    afterFile: 'realtor-prelist-after.webp',
    beforeAlt:
      'Empty listing room with dated orange-red high-gloss oak, scratches and traffic lanes, sliding door to a deck.',
    afterAlt:
      'The same listing room after a full sand and lighter satin finish, ready for photography.',
    routes: ['/realtors'],
    ctaHref: '/realtors',
    ctaLabel: 'Pre-list floor recoat',
    status: 'recapture',
  },
  distilleryLoft: {
    id: 'distillery-loft',
    kicker: 'PROOF',
    headline: 'Same loft. Same brick. Different floor.',
    factline:
      'Distillery District Victorian loft. White oak engineered, glue-down over a measured concrete slab.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'distillery-loft-before.webp',
    afterFile: 'distillery-loft-after.webp',
    beforeAlt:
      'Raw Distillery District loft: factory windows, exposed brick, stained concrete slab before hardwood.',
    afterAlt:
      'The same loft after a white oak glue-down over concrete, matte oil finish, one lounge chair.',
    jobSlug: 'distillery-district-victorian-condo',
    routes: [
      '/case-studies/distillery-district-victorian-condo',
      '/service-areas',
      '/commercial',
      '/hardwood-flooring-toronto',
    ],
    ctaHref: '/case-studies/distillery-district-victorian-condo',
    ctaLabel: 'Read what was measured',
    status: 'slider-ready',
  },
  problemsCupping: {
    id: 'problems-cupping',
    kicker: 'PROOF',
    headline: 'The gap is climate. The grey is finish.',
    factline:
      'Winter gapping and oxidized wear on maple, then a full sand and waterborne finish. Board-level crop — not a hero.',
    instruction: 'Drag the slider.',
    leftHandle: 'before',
    rightHandle: 'after',
    beforeFile: 'problems-cupping-before.webp',
    afterFile: 'problems-cupping-after.webp',
    beforeAlt:
      'Close-up of a failing Toronto hardwood floor: grey oxidized boards, open winter gaps, surface wear.',
    afterAlt:
      'Close-up of the same floor after repair, sanding and refinishing: tight seams, flat boards, honey satin maple.',
    routes: ['/hardwood-floor-problems-toronto'],
    ctaHref: '/hardwood-floor-problems-toronto',
    ctaLabel: 'Why floors fail here',
    status: 'slider-ready',
  },
} as const satisfies Record<string, ProofPlate>;

export type ProofPlateId = keyof typeof PROOF_PLATES;

export function proofSrc(file: string): string {
  return `${DIR}/${file}`;
}

export function proofJpg(file: string): string {
  return `${DIR}/${file.replace(/\.webp$/, '.jpg')}`;
}

/** Homepage flagship — mount after PricingSection, before JobCardRail. */
export const HOMEPAGE_PLATE = PROOF_PLATES.richmondHillMaple;

/** JobCard imageSlot: use the AFTER still until the slider ships on the card. */
export const JOBCARD_AFTER_STILL: Partial<Record<string, string>> = {
  'forest-hill-walnut-wide-plank-color-stability': proofSrc(
    PROOF_PLATES.forestHillWalnut.afterFile,
  ),
  'distillery-district-victorian-condo': proofSrc(
    PROOF_PLATES.distilleryLoft.afterFile,
  ),
  'rosedale-estate-stairs-radiant-heat': proofSrc(
    PROOF_PLATES.rosedaleStairs.afterFile,
  ),
};
