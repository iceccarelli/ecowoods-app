# Where the detail stills go

| Surface | Pair |
|---|---|
| Project page body | After each wide still, the matching detail |
| Stairs & railings | Details 01, 02, 05, 06, 07, 08 |
| Collection — Hard Maple | Details 13, 04, 15, 17 |
| Thresholds / technical module | Details 18, 20 |
| Case study “what we watched” | Details 08, 11, 13, 18 |
| Home proof rail | Rotate 08, 13, 18 |

Suggested caption component (one line):

> Detail 18 — Stone and maple on one plane. The reducer is the joint, not a ramp.

Filename pattern:

`ecowoods-maple-glass-detail-{NN}-{what-you-are-looking-at}.jpg`
