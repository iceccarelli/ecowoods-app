# Ecowoods — Maple & Glass Residence DETAIL pack

Twenty zoomed stills. Same job as the wide set. Each frame is a single craft decision.

| Zip | Contents | Use |
|---|---|---|
| `01-ecowoods-maple-glass-DETAILS-hero-16x9-4k.zip` | 20 × 3840×2160 + contact sheet | Spotlight modules, full-bleed detail bands |
| `02-ecowoods-maple-glass-DETAILS-gallery-3x2.zip` | 20 × 3600×2400 | Editorial pair next to the wide 3:2 |
| `03-ecowoods-maple-glass-DETAILS-web-1920.zip` | 20 × 1920×1080 | Site “the work, closer” rail |
| `04-ecowoods-maple-glass-DETAILS-thumbs-960.zip` | 20 × 960×540 | Previews |
| `05-ecowoods-maple-glass-DETAILS-copy.zip` | Notes, placement, manifest | Captions and pairing rules |

Every still is landscape, branded with the EW mark, and carries a caption bar: `DETAIL NN · ECOWOODS` plus the human title.

Unzip into:

```
public/images/projects/maple-glass-residence/details/{hero,gallery,web,thumbs}
```

Pair `detail-NN` with the existing wide file `residence-NN`.
