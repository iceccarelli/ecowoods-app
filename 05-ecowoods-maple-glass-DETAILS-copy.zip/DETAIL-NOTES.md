# Maple & Glass Residence — 20 spotlight details

These stills are the same 20 job-site frames, cropped into the work itself. Each one is a single thing Ecowoods was responsible for. Use them next to the wide shots: wide shot first, detail second. That is the Ferrari move — the car, then the stitch.

Repo folder:

```
public/images/projects/maple-glass-residence/details/
  hero/
  gallery/
  web/
  thumbs/
```

Pairing rule on the site: `ecowoods-maple-glass-residence-NN-…` (wide) sits with `ecowoods-maple-glass-detail-NN-…` (zoom). Same number, same room, different distance.

---

## 01 — Tread-to-landing grain match
**File:** `ecowoods-maple-glass-detail-01-tread-to-landing-grain-match.jpg`  
**Spot:** Last open risers arriving on the mid landing.  
**What was done:** Treads and landing came from the same maple run. Colour, grain direction and thickness read as one plane.  
**What was taken care of:** No “stair colour” vs “floor colour.” Nosing stays crisp against the glass. Joints on the landing are staggered, not stacked under the well.

## 02 — Open-riser profile on the steel stringer
**File:** `ecowoods-maple-glass-detail-02-open-riser-profile-black-stringer.jpg`  
**Spot:** Side of a maple tread leaving the black stringer.  
**What was done:** Each tread is a finished maple plank. The riser is left open on purpose so light and the stringer stay in the room.  
**What was taken care of:** Square exposed edge, even projection, no raw end-grain facing the void.

## 03 — Landing field, joint stagger
**File:** `ecowoods-maple-glass-detail-03-landing-field-joint-stagger.jpg`  
**Spot:** Boards where the flight meets the landing under the void.  
**What was done:** The landing is laid as floor, not as leftover offcuts.  
**What was taken care of:** Same species and satin as the flights above and below. No orphan short board in the middle of the well.

## 04 — Satin sheen in window light
**File:** `ecowoods-maple-glass-detail-04-satin-sheen-window-wash.jpg`  
**Spot:** Maple beside the primary window wall.  
**What was done:** Natural satin — the floor returns light, it does not flash.  
**What was taken care of:** Even film build. Grain still reads. Hard sun stays cream, not plastic-white and not yellow.

## 05 — Landing edge at the glass void
**File:** `ecowoods-maple-glass-detail-05-landing-edge-at-glass-void.jpg`  
**Spot:** Upper floor breaking into the stair well.  
**What was done:** The floor is carried to the glass line as a maple edge, not stopped in a metal channel.  
**What was taken care of:** Straight drop line, boards locked so the edge cannot creep, consistent overhang.

## 06 — First tread on the floor plane
**File:** `ecowoods-maple-glass-detail-06-first-tread-floor-plane.jpg`  
**Spot:** Upper-floor boards meeting the first open riser.  
**What was done:** The stair does not start in a different colour. The floor continues into air.  
**What was taken care of:** Plank direction held. Meeting at the opening is flush. No visible height change.

## 07 — Glass corner, maple return
**File:** `ecowoods-maple-glass-detail-07-glass-corner-maple-return.jpg`  
**Spot:** Inside corner of the frameless guard at the stair mouth.  
**What was done:** Glass is another trade. The maple still returns clean under the clamp so hardware sits on a finished edge.  
**What was taken care of:** Square opening. Tight board ends at the glass. No filler at the corner.

## 08 — Underside fastener rhythm
**File:** `ecowoods-maple-glass-detail-08-underside-fastener-rhythm.jpg`  
**Spot:** Looking up the open-riser flight.  
**What was done:** The underside is finished because the void is a room. Fasteners sit on one rhythm. Grain on the soffit follows the walking line.  
**What was taken care of:** Even reveal between treads. No wild screw pattern. No unfinished maple facing the floor below.

## 09 — Unbroken run through the doorway
**File:** `ecowoods-maple-glass-detail-09-doorway-run-unbroken.jpg`  
**Spot:** Maple passing the suite door.  
**What was done:** One species, one direction, one sheen through the door. The threshold is the door, not a change of floor.  
**What was taken care of:** Boards carried through the opening. No reducer between suite and hall.

## 10 — Plank direction held through the hall
**File:** `ecowoods-maple-glass-detail-10-plank-direction-through-hall.jpg`  
**Spot:** Field in the suite looking toward the void.  
**What was done:** Layout was set on the long axis of the house so every room is the same floor travelling.  
**What was taken care of:** Stagger held across the threshold. No change of width or grade mid-run.

## 11 — Joint discipline in a narrow run
**File:** `ecowoods-maple-glass-detail-11-narrow-run-joint-discipline.jpg`  
**Spot:** Dressing corridor between glass wardrobes.  
**What was done:** A long tight room shows every bad joint. Ends are parked at walls and cabinets, not in the walking line.  
**What was taken care of:** Parallel to the millwork. Even margins. No short filler strip down the centre.

## 12 — Long-axis end match
**File:** `ecowoods-maple-glass-detail-12-long-axis-end-match.jpg`  
**Spot:** Dressing gallery toward the far light.  
**What was done:** One decision from door to far wall. End joints step, they do not stack.  
**What was taken care of:** Consistent width against tall millwork. No colour drift down the length.

## 13 — Select maple, cathedral grain
**File:** `ecowoods-maple-glass-detail-13-select-maple-cathedral-grain.jpg`  
**Spot:** Close field in the dressing room.  
**What was done:** This is the grade used through the house — hard maple, select, natural satin.  
**What was taken care of:** Face-matched boards. Tight side joints. Sheen even across earlywood and latewood. Almost no mineral streak, no character knots. Quiet on purpose.

## 14 — Field beside the platform bed
**File:** `ecowoods-maple-glass-detail-14-field-beside-platform-bed.jpg`  
**Spot:** Maple running past the bed toward the ensuite.  
**What was done:** The floor is the finished plane the bed sits on. Layout does not break around the platform.  
**What was taken care of:** Flat field. Tight seams. Colour held next to grey stone and walnut.

## 15 — Light breaking across the boards
**File:** `ecowoods-maple-glass-detail-15-light-break-across-boards.jpg`  
**Spot:** Sun line on maple in the primary suite.  
**What was done:** Proof of the satin. The sun line is a soft step in tone, not a glare stripe.  
**What was taken care of:** No blotch at the light break. No raised grain. Boards seated flat so the line stays straight.

## 16 — Staggered ends in the suite field
**File:** `ecowoods-maple-glass-detail-16-staggered-ends-in-the-suite.jpg`  
**Spot:** Boards in front of the walnut headboard wall.  
**What was done:** End joints are stepped so the field does not form a ladder.  
**What was taken care of:** Minimum stagger held. No cluster of butts in the open field.

## 17 — Colour hold across the room
**File:** `ecowoods-maple-glass-detail-17-colour-hold-across-the-room.jpg`  
**Spot:** Diagonal of the primary suite.  
**What was done:** Maple can drift yellow board to board. This run was sorted so the room stays one cream.  
**What was taken care of:** Board sorting before lay-up. Same finish batch. No replacement plank that reads as a patch.

## 18 — Stone-to-maple flush reducer
**File:** `ecowoods-maple-glass-detail-18-stone-to-maple-flush-reducer.jpg`  
**Spot:** Joint between large-format tile and the living-room maple.  
**What was done:** Two materials, one plane. The maple is reduced to the stone. The joint is a line, not a product.  
**What was taken care of:** Height match after both trades. Clean reducer profile. Board ends cut square to the stone. No ramp, no lip.

## 19 — Board run to the media wall
**File:** `ecowoods-maple-glass-detail-19-board-run-to-media-wall.jpg`  
**Spot:** Living-room maple arriving at the walnut millwork.  
**What was done:** Planks are aimed at the media wall so the room has one direction.  
**What was taken care of:** Direction held from the stone joint to the wall. Even reveal at the base. Colour quiet under the linear lights.

## 20 — Hall reducer and vent cut
**File:** `ecowoods-maple-glass-detail-20-hall-reducer-and-vent-cut.jpg`  
**Spot:** Maple-to-stone joint in the connecting hall.  
**What was done:** The same flush reducer as the living room, carried through the hall so the two materials stay on one plane.  
**What was taken care of:** Square cut to the tile. Plane match at the threshold. The joint does not change language from room to room.

---

## How to use them with customers

On a project page, a service page, or a walkthrough:

1. Show the wide still (`residence-NN`).
2. Immediately show the detail (`detail-NN`).
3. Put one sentence under the detail — the **What was done** line above.

Do not run the 20 details as a standalone dump. They only work when the customer has already seen the room.
