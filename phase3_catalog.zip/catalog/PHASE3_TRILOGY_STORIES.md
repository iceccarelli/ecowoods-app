# Ecowoods Trilogy — Phase 3 (The Fingertip)

Third and last frame for every image.

Pair `01-` (room) + `02-` (approach) + `03-` (this set) on the same card or carousel.

Trilogy: Frame 1 = the room. Frame 2 = the approach. Frame 3 = the fingertip.

Official EW mark signed lower-right.


## 01_homepage_hero

### 03-hero-salon-dark-oak-chandelier.jpg
**Beat title:** The Grain
Two boards. One joint. Chandelier light across open oak pores. This is why the room in Frame 1 feels expensive.

### 03-hero-salon-fireplace-continuous-floor.jpg
**Beat title:** The Seam
A single plank end-joint on the line that runs through the arch. Continuity proven at fingertip distance.

### 03-hero-geometric-parquet-french-doors.jpg
**Beat title:** The Meeting
Versailles geometry resolved to one crossing of boards. Pattern is joinery, not decoration.


## 07_grand_rooms

### 03-grand-paneled-oval-room-herringbone.jpg
**Beat title:** The Reverse
Herringbone where grain turns. The oval hall in Frame 1 is built from this decision, repeated.


## 02_custom_inlays

### 03-custom-floral-medallion-inlay.jpg
**Beat title:** The Petal
Dark wood flower set into oak. Inlay seam you can almost feel. The signature from Frame 2, now under glass.

### 03-custom-geometric-border-parquet-study.jpg
**Beat title:** The Cross
Dark border crossing light oak. Two species, one line. The study rhythm reduced to a single intersection.

### 03-library-chevron-wide-band-parquet.jpg
**Beat title:** The Point
Chevron V. Grain coming at itself. The library floor’s entire argument in one joint.

### 03-geometric-versailles-parquet-estate.jpg
**Beat title:** The Diamond
One framed diamond. The estate parquet from Frames 1 and 2, now a single module you could hold.


## 06_craftsmanship_details

### 03-detail-geometric-inlay-borders.jpg
**Beat title:** The X
Four strips meeting. Joinery as the whole picture.

### 03-detail-herringbone-oak-border.jpg
**Beat title:** The Pore
Oak cells against the dark border. As close as a camera is allowed.


## 03_hardwood_stairs

### 03-stairs-curved-oak-iron-balustrade.jpg
**Beat title:** The Nosing
Bullnose profile. Grain wrapping the edge the foot will find.

### 03-stairs-sculptural-handrail-curve.jpg
**Beat title:** The Hold
The rail under a hand. Finish and grain along the curve. Frame 2 was the shape; this is the touch.

### 03-stairs-foyer-oak-treads-iron.jpg
**Beat title:** Wood and Stone
Rounded oak sitting on cream tile. The foyer problem, solved in one joint.

### 03-stairs-spiral-looking-down.jpg
**Beat title:** The Wedge
Two pie treads. The spiral from above becomes two boards and a seam.


## 04_residential_floors

### 03-residential-dark-oak-plank-living.jpg
**Beat title:** The Sheen
Plank seam and window light. The living-room floor reduced to finish quality.

### 03-residential-oak-hallway-closet-transition.jpg
**Beat title:** The Line
Oak stops on stone. Threshold as a product shot.

### 03-residential-herringbone-dormer-room.jpg
**Beat title:** The V
Herringbone point at fingertip scale. The dormer room’s pattern, isolated.

### 03-residential-loft-kitchen-light-strip.jpg
**Beat title:** The Knot
Character grade, honestly. The kitchen floor’s story is this knot.


## 05_commercial

### 03-commercial-rickis-store-maple-strip.jpg
**Beat title:** The Traffic Surface
Maple grain and a clean seam. Commercial floor as material, not aisle.

### 03-commercial-rickis-storefront.jpg
**Beat title:** The Cut
Hardwood meeting mall tile. The store begins on this line.
