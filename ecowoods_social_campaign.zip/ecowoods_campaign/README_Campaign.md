# Ecowoods Aggressive Paid Social Campaign Assets

**Campaign Objective:** Drive high-intent traffic to the Floor Designer + free in-home estimate booking pipeline on [ecowoods.ca](https://ecowoods.ca).

**Platforms:** Facebook, Instagram, TikTok (feed + stories/reels)

**Tone:** Aggressive, pattern-interrupting, anti-contractor-BS. Direct-response. No corporate fluff.

## Core Value Propositions Weaponized
- 99.7% dust-free HEPA sanding (Festool systems) — live in your home
- Fixed price in writing — estimate = invoice, zero change orders
- Salaried master craftsmen only — zero subcontractors
- Toronto/GTA exclusive operations (25+ years, 5,200+ homes)
- 25–50 year manufacturer warranties passed in writing
- Zero-formaldehyde, water-based ≤50 g/L VOC eco finishes

## Assets Included

### Images (WebP, high-resolution, photorealistic)
1. `01_before_after_oak.webp` — Dramatic 100-year-old red oak → modern hardwax-oil finish split
2. `02_festool_hepa_sanding.webp` — Master artisan + Festool + HEPA hoses in furnished room
3. `03_white_oak_walnut_inlay.webp` — Sunlit wide-plank white oak + custom walnut fireplace inlay
4. `04_eco_finish_macro.webp` — Extreme macro of water-based eco finish on raw oak grain
5. `05_homeowner_artisan_handshake.webp` — Trust handshake with written fixed-price quote

### Structured Copy
See `campaign_assets.json` for machine-readable hooks, bodies, captions, and CTAs for each image.

## Deployment into Monorepo

Place all files into:
```
public/assets/marketing/
```

### Exact Git CLI Commands

```bash
# From the root of the iceccarelli/ecowoods-app monorepo
mkdir -p public/assets/marketing

# Extract the zip (or copy files)
unzip ecowoods_social_campaign.zip -d /tmp/ecowoods_campaign
cp /tmp/ecowoods_campaign/*.webp public/assets/marketing/
cp /tmp/ecowoods_campaign/campaign_assets.json public/assets/marketing/
cp /tmp/ecowoods_campaign/README_Campaign.md public/assets/marketing/

# Stage and commit
git add public/assets/marketing/
git commit -m "feat(marketing): add aggressive paid social campaign assets (5 images + structured copy)

- Photorealistic 8k ad creatives for FB/IG/TikTok
- Pattern-interrupt hooks targeting dust, surprise fees, subcontractors
- Weaponizes fixed-price, HEPA 99.7%, salaried craftsmen USPs
- JSON for dynamic ad loading + human-readable README"
git push
```

## Usage Notes for Ad Manager
- Primary CTA: Drive to https://ecowoods.ca (Floor Designer + #quote form)
- Secondary: Phone (647) 244-5156
- Audience: Homeowners 35–65 in Toronto / GTA with hardwood floors, interest in home renovation / real estate
- Test hooks first — they are designed to stop the scroll hard

---
*Generated for Ecowoods monorepo deployment — July 2026*
