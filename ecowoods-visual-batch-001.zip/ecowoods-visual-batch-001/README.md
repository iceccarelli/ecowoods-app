Ecowoods visual batch 001: 21 image files from production + maps.
